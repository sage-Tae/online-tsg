# Cover Letter

**To:** Professor Roman Słowiński, Co-ordinating Editor-in-Chief
**Journal:** European Journal of Operational Research
**Date:** [YYYY-MM-DD — author to fill in on submission day]

**Re:** New submission — *Online Traveling Salesman Games: Temporal
Nucleolus and the Fragility of the Core under Dynamic Arrivals*

**Authors:**
Seyun Jeong (Department of Industrial and Management Engineering,
POSTECH, Pohang, Republic of Korea)
Hyunchul Tae (Korea Institute of Industrial Technology, Cheonan,
Republic of Korea) — *corresponding author, [e-mail to fill in]*

---

Dear Professor Słowiński,

We submit the enclosed manuscript for consideration as a new
research article in *EJOR*. The paper extends the cooperative
Traveling Salesman Game of Potters, Curiel and Tijs (1992) to an
online setting in which customers arrive over time, couples the
cooperative-game stability question to the realized dispatch
dynamics, and provides both analytic and computational results.
The topic sits at the intersection of routing and cooperative game
theory, a combination with strong *EJOR* precedent (Göthe-Lundgren,
Jörnsten & Värbrand 1996; Helsgaun 2000; Kimms & Kozeletskyi 2016;
Nguyen & Thomas 2016; Guajardo & Jörnsten 2015; Tae, Kim & Park
2020).

## Core contribution

We introduce the *Online Traveling Salesman Game* $(N, c, \mathcal{F})$,
a cooperative game in which the family $\mathcal{F}$ of
feasibility-admissible coalitions is endogenously induced by the
realized arrival–service process rather than specified exogenously
as in Myerson-style graph-restricted or antimatroid-restricted
games. On this family we define the *Temporal Nucleolus* as the
lexicographic minimizer of excess and compute it by a sequential
linear program over $\mathcal{F}$.

The paper's theoretical contribution is three complementary
sufficient conditions for Temporal Core emptiness — a single-complement
threshold $r^{**}$ (Theorem 11), a balanced-complement threshold
$r^{***}$ (Proposition 12), and a balanced-near-complement threshold
$r^{(\diamond)}$ on the mixed collection $B_{n-1}\cup B_{n-2}$
(Proposition 15) — together with a structural obstruction
(Corollary 20): a bounded peak queue $k < n-1$ simultaneously
blocks all three mechanisms. The three analytic conditions
collectively certify 57 of the 67 observed empty Cores in our
175-instance grid (85 percent), with no false positives across
525 policy-instance pairs. An asymptotic refinement (Theorem 17)
ties $r^{**}\to 1$ to the classical Beardwood–Halton–Hammersley
$\sqrt{n}$ scaling.

## Scope and methodological choice

The paper is scoped to a single-vehicle routing game. This is a
deliberate methodological choice — the single-tour setting isolates
the temporal coalition-feasibility structure of $\mathcal{F}$ from
fleet-assignment confounds, and the three complement-based arguments
rely on the single-vehicle insertion identity. A multi-vehicle
*Online Vehicle Routing Game* — requiring $c(S)$ redefined with
capacity and a fleet-assignment rule — is the subject of a companion
manuscript in preparation.

## Reproducibility

All code, random seeds, and raw CSV results are at
<https://github.com/sage-Tae/online-tsg>. The repository ships
version tags for each iteration in the revision history, including
the current `v2.2.2`. `REPRODUCIBILITY.md` documents the environment,
the full 175-instance main study (Table 5), the 45-instance
scale-up to $n=50$, and the new `code/scripts/
near_complement_coverage_check.py` used to verify the empirical
coverage of Proposition 15.

## Declarations

- No conflict of interest.
- The work reported has not been published elsewhere, and is not
  under consideration at any other journal.
- All authors have read and approved this submission.

We thank the editorial office in advance for handling this
manuscript and look forward to the reviewers' feedback.

Sincerely,

**Hyunchul Tae**, on behalf of the authors
Korea Institute of Industrial Technology
[e-mail to fill in]
[ORCID to fill in]

---

### Author-side placeholders (to fill before submitting)

- Submission date.
- Corresponding author's current e-mail.
- ORCID identifiers for both authors.
- Verify the corresponding-author designation matches the authors'
  current preference.
