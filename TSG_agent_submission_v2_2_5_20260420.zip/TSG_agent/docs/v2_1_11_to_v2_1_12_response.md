# v2.1.11 → v2.1.12 response

Minimal-scope reference-accuracy patch. Triggered by the v2.1.11
verification report (`docs/v2_1_11_verification_report.md`), which flagged
two bib errors (V2.1 FAIL, V2.4 FAIL). No other changes.

## Summary

| Patch | Item | Status | Addresses |
|---|---|---|---|
| P1 | Remove hallucinated Klijn & Slikker (2005) | **Done** | V2.1 FAIL |
| P2 | Correct Drechsel & Kimms (2010) venue | **Done** | V2.4 FAIL |
| — | Version bump v2.1.11 → v2.1.12 | **Done** | — |

## P1 — Klijn & Slikker (2005) removed

**Problem.** The v2.1.11 bib entry cited the paper as *Mathematical Methods
of Operations Research* vol 62 issue 1, pp. 69–86, 2005. The verification
report established that (a) the TOC of *Math. Methods of OR* vol 62 issue 1
(Sept 2005) contains no paper by these authors with the listed title, and
(b) DBLP's profile for Flip Klijn shows no joint publication with Marco
Slikker in 2005. The reference was a hallucination.

**Actions.**

- **P1.a** — `paper/references.bib`: the `@article{klijn2005sequencing, ...}`
  entry is deleted in full.
- **P1.b** — `paper/main.tex` §2.2 (line 94): the single citing sentence

  > "\citet{klijn2005sequencing} analyze sequencing games where arrival
  > order can render coalitions infeasible, an admissibility principle we
  > adapt to the metric TSP under an online arrival-service process rather
  > than a fixed permutation."

  is removed entirely. No substitute citation is added, per the patch
  spec. The point about admissibility being adapted from sequencing-game
  literature is unclaimed in v2.1.12.
- **P1.c** — grep over `paper/main.tex`, `paper/supplementary.tex`, and
  `paper/references.bib` confirms no remaining occurrences of "Klijn" or
  "klijn2005sequencing".

**Net effect on §2 citation count.** v2.1.11 added five new references in
§2 (Klijn & Slikker, Platz & Hamers, Özener & Ergun 2008, Drechsel & Kimms,
Özener et al. 2013). v2.1.12 retains four of them; the fifth is deleted.

## P2 — Drechsel & Kimms (2010) venue corrected

**Problem.** The v2.1.11 bib entry cited the paper as *Computers & Industrial
Engineering* vol 59 issue 4, pp. 547–555, 2010. The verification report
established that the paper with the exact title, authors, and year exists
but was published in *International Journal of Production Economics*,
vol 128 issue 1, pp. 310–321, November 2010 (ScienceDirect pii
S0925527310002689; IDEAS/RePEc entry
`ideas.repec.org/a/eee/proeco/v128y2010i1p310-321.html`). The `C&IE 59(4)`
range 547–555 in reality belongs to an unrelated Ji & Xia paper. The title,
authors, and year in the bib entry are correct; only the bibliographic
coordinates are wrong.

**Actions.**

- **P2.a** — `paper/references.bib`: the `@article{drechsel2010computing, ...}`
  entry's `journal`, `volume`, `number`, and `pages` fields are replaced
  with
  ```
  journal = {International Journal of Production Economics},
  volume  = {128},
  number  = {1},
  pages   = {310--321},
  ```
  Bib key, authors, title, and year unchanged.
- **P2.b** — `paper/main.tex` §2.2 (line 94): grep confirms the in-text
  citation is `\citet{drechsel2010computing}` only; the journal name is
  not mentioned inline, so no in-text correction is required. The
  sentence is unchanged.

## Version bump + docs

- `README.md`:
  - Header current-version label v2.1.11 → v2.1.12.
  - "Key results" block header v2.1.11 → v2.1.12.
  - Version-history block extended with a v2.1.12 entry summarising P1 + P2.
  - Reproducibility-tags section: v2.1.11 rolled into the intermediate-
    iterations list; v2.1.12 added as the current tag with a detailed
    per-patch summary.
- `REPRODUCIBILITY.md`:
  - Title, intro, and Paper Info block version strings v2.1.11 → v2.1.12.
  - "Data Files (v2.1.11)" heading → "(v2.1.12)".
  - Two inline "v2.1.11" version strings in body paragraphs bumped.
  - "Both are expected to pass on a clean v2.1.11 checkout" → v2.1.12.
  - Version History block: v2.1.11 demoted to intermediate; v2.1.12 added
    with a detailed per-patch summary.
- `scripts/verify_doc_consistency.sh`:
  - `CURRENT_VERSION=v2.1.11` → `v2.1.12`.
  - Stale-version regex extended to match v2.1.11 explicitly (previously
    ended at v2.1.10 due to the `\b` word-boundary quirk on
    two-digit subversions).

## Invariants preserved

- No theoretical, experimental, or numerical results modified.
- No figures, CSVs, or code files modified.
- All Theorem / Proposition / Corollary / Remark / Observation statements
  and proofs unchanged.
- Supplementary §S4 (open-problem statement added in v2.1.11) unchanged.
- Page counts unchanged: main 30, supplementary 7, highlights 1.
- Example 4 TNu allocation unchanged.
- Table 5 / Table 6 / Table 7 / Table 8 counts unchanged.
- Sharpness factors (3.56, 3.97) and threshold means (4.351, 1.223, 1.096)
  unchanged.

## Verification gates (expected PASS after this patch)

- `scripts/verify_doc_consistency.sh` — should PASS with current version
  v2.1.12, main 30 / supplementary 7, seed123 = 2 rows, no stale v2.1.0–
  v2.1.11 labels outside historical blocks.
- `scripts/verify_zip_rebuild.sh <zip>` — should PASS with main.pdf ≤ 30
  pages, supplementary.pdf and highlights.pdf compiling clean.

## Residual items from `v2_1_11_verification_report.md`

- V2.1 FAIL (Klijn & Slikker) — **addressed by P1**.
- V2.4 FAIL (Drechsel & Kimms venue) — **addressed by P2**.
- V4.b FAIL (labels not renamed to `prop:`) — **not addressed**; this is
  the documented intentional deviation from v2.1.11 (labels
  `thm:static-equiv` and `thm:core-inheritance` preserved for downstream
  cross-reference compatibility per the outer v2.1.11 spec's preservation
  constraint). Out of scope for this minimal-scope patch.
