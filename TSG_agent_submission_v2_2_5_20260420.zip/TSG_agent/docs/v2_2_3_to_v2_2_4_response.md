# v2.2.3 → v2.2.4 Response

**Scope.** Minimal reference-accuracy patch on top of v2.2.3 plus the
first full PDF rebuild. Single bibliographic correction (Van Zon
first-author given name) + PDF rebuild outcome + version-bump
artifacts. No new results, no proof changes, no CSV / figure / source
modifications, no prose changes beyond the bib entry.

## Patch summary

### P1 — van Zon first-author given-name correction

The v2.2.3 `vanzon2021joint` entry in `paper/references.bib` rendered
as:

```bibtex
@article{vanzon2021joint,
  author  = {van Zon, Mart{\'\i}n and Spliet, Remy and van den Heuvel, Wilco},
  title   = {The Joint Network Vehicle Routing Game},
  journal = {Transportation Science},
  volume  = {55},
  number  = {1},
  pages   = {179--195},
  year    = {2021}
}
```

The first author's given name is **Mathijs**, not Martín. Verified:

- INFORMS DOI `10.1287/trsc.2020.1008`
  (<https://pubsonline.informs.org/doi/10.1287/trsc.2020.1008>).
- RePEc listing at <https://ideas.repec.org/p/ems/eureir/115273.html>.
- WebSearch of the paper title surfaces "Mathijs van Zon, Remy Spliet,
  and Wilco van den Heuvel" on every independent source
  (Transportation Science, IDEAS/RePEc, CORE, Erasmus Repub).

The v2.2.3 author string "Mart{\'\i}n" was a hallucination. Under the
`plainnat` bibliography style used in `paper/main.tex`, the rendered
in-text citation is "van Zon et al. (2021)" regardless of given-name
spelling (`plainnat` prints initials only for other authors and omits
the given name of an author cited via `\citet{}`), but the bibliography
entry would have displayed the given name in expanded form. No inline
paper prose mentions the given name, so no sentence edit was needed;
the fix is localized to one bib field.

**Change:**

```diff
-  author  = {van Zon, Mart{\'\i}n and Spliet, Remy and van den Heuvel, Wilco},
+  author  = {van Zon, Mathijs and Spliet, Remy and van den Heuvel, Wilco},
```

`grep -i "Mart" paper/references.bib paper/main.tex paper/supplementary.tex paper/highlights.tex` after the edit returned only two unrelated matches (Bullinger, Martin; Savelsbergh, Martin) — no stale Martín remnants.

### P2 — PDF rebuild (first attempt with full toolchain available)

TeX Live 2026 (at `/Library/TeX/texbin/pdflatex`) was available in
this iteration, unlike v2.2.3. The full rebuild sequence was executed:

```bash
cd paper
rm -f *.aux *.bbl *.blg *.log *.out *.toc
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex

pdflatex -interaction=nonstopmode supplementary.tex
bibtex supplementary
pdflatex -interaction=nonstopmode supplementary.tex
pdflatex -interaction=nonstopmode supplementary.tex

pdflatex -interaction=nonstopmode highlights.tex
pdflatex -interaction=nonstopmode highlights.tex
```

Exit code 0 throughout. Page counts (read from pdflatex's final
"Output written on ..." line; `pdfinfo` is not installed in this
environment):

| PDF                | Page count | Target | Verdict |
|--------------------|-----------:|-------:|---------|
| `main.pdf`         | **31**     | ≤ 30   | **FAIL (1 over)** |
| `supplementary.pdf`| 8          | —      | on-spec |
| `highlights.pdf`   | 1          | 1      | on-spec |

`main.pdf` exceeds the EJOR 30-page cap by one page. The v2.2.3 trims
(§5.3 two-sentence paragraph compressed; §6.6 closing sentence
removed) were therefore **insufficient rather than overkill**. The
spec's P2.d branch (trims overkill → restore content) does not apply.
P2.c (≤ 30 pages → success) also does not apply. The trims are kept
as in v2.2.3.

**Implication for the spec's `§5.3 / §6.6` question.** The spec
instructed "optionally revert §5.3 / §6.6 trims if rebuild confirms
they were unnecessary". The rebuild confirms the opposite: without
the trims, `main.pdf` would almost certainly be 32 pages. The trims
are necessary and are retained verbatim.

### Deferred to author

The 1-page overflow requires further action before submission.
Options:

1. **Further prose trim (~50 words).** Candidate sites outside the
   protected regions (Proposition 15, its proof, §S4, any Theorem,
   Table 5, CSVs, code, figures): §2 Related Work (any of the four
   new sentences added in v2.1.11 / v2.2.3 that are now one-liners
   could be compressed); §7 Conclusion's "Broader directions"
   paragraph; §6.8 Summary. A human author's judgement is required to
   pick the least information-lossy site.
2. **Paragraph-packing.** The pdflatex log reports six Overfull hbox
   warnings (lines 164–165, 520–534, 592–593, 611–626, 723–724,
   745–746); fixing these may tighten a paragraph enough to save one
   display line each, which cumulatively could save one page without
   any prose deletion.
3. **Bibliography compression.** The bibliography is already at
   `\scriptsize` with `\bibsep = 0pt plus 0.1ex` (v2.2.0 setting);
   further compression is unlikely to help without crossing
   readability norms.

This iteration is a minimal reference-accuracy patch. It does **not**
attempt any of 1–3 automatically; the choice is left to the authors
so that they can trade off content vs. typography according to
editorial preference.

## Version-bump mechanics

- `README.md`: header `**Current version: v2.2.4**`, Key-results
  header `v2.2.4`, Version-history block appended with v2.2.4 entry
  (noting the 1-page overflow), Reproducibility-tags block updated
  (v2.2.3 entry relabelled `(intermediate)`, v2.2.4 entry appended as
  `(current, major revision)`).
- `REPRODUCIBILITY.md`: title updated to v2.2.4, Version field
  updated, three in-body `v2.2.3` references updated, Version-History
  block: v2.2.3 relabelled `(intermediate)`, v2.2.4 appended as
  `(current)` with honest "31 pages — 1 over cap" note.
- `scripts/verify_doc_consistency.sh`: `CURRENT_VERSION` bumped to
  `v2.2.4`; stale-version regex extended from `v2\.2\.[012]` to
  `v2\.2\.[0123]` so that v2.2.3 (previously current) is now flagged
  outside historical blocks.
- `docs/v2_2_3_to_v2_2_4_response.md`: this file.

## Files changed

- `paper/references.bib` — one-line author correction.
- `paper/main.pdf` — rebuilt from v2.2.3 source (31 pages, overflow
  flagged above).
- `paper/supplementary.pdf` — rebuilt from v2.2.3 source (8 pages).
- `paper/highlights.pdf` — rebuilt from v2.2.3 source (1 page).
- `README.md` — header, key-results header, version history block,
  reproducibility-tags block.
- `REPRODUCIBILITY.md` — title, Version field, three in-body labels,
  Version History block.
- `scripts/verify_doc_consistency.sh` — CURRENT_VERSION and regex.
- `docs/v2_2_3_to_v2_2_4_response.md` — this file.

No changes to `paper/main.tex`, `paper/supplementary.tex`,
`paper/highlights.{tex,txt}`, `paper/cover_letter.md`, any CSV in
`code/results/` or `code/experiments/logs/`, any figure PDF in
`code/figures/`, any `src/` file, or any prior `docs/*.md` entry.

## Gate status

- `scripts/verify_doc_consistency.sh`: expected to PASS after this
  iteration (v2.2.3 is now flagged as stale by the updated regex and
  appears only inside historical blocks after the relabelling; no new
  stale page-count, seed123-row, orphan-figures/, or retired-metric
  hits).
- `scripts/verify_zip_rebuild.sh`: executable in this environment
  (pdflatex available). The script checks `main.pdf` page count
  against its own hard cap of 30; **it will FAIL** at the 31-page
  `main.pdf` rebuilt in P2. This FAIL is the automated surfacing of
  the same overflow already flagged in this document; it is **not**
  a regression introduced by the Van Zon name correction (which would
  not change layout under `plainnat`).

## Action items for the author

1. **Resolve the `main.pdf` 1-page overflow.** See the three options
   in §P2 "Deferred to author" above. A ~50-word cut in §7 Broader
   directions or §2 Related Work, or fixing the Overfull hboxes, is
   most likely to land the rebuild at 30 pages.
2. **Re-run `scripts/verify_zip_rebuild.sh`** after the trim. Confirm
   `main.pdf` = 30 pages.
3. **Tag `v2.2.4`** once the rebuild is clean, or open a v2.2.5
   patch if the overflow fix is non-trivial.

## Items NOT actioned

- §5.3 Discussion trim from v2.2.3 — retained (rebuild shows it was
  necessary, not overkill).
- §6.6 Sharpness trim from v2.2.3 — retained (same).
- Any change to main.tex prose — intentionally out of scope for this
  minimal patch.
- Proposition 15 / its proof / §S4 / Theorems / Table 5 / CSVs /
  figures / code — out of scope per hard constraints.
