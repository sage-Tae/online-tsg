# Phase-2 Option 1 working log: near-complement promotion attempt

## 2026-04-19 22:25 KST — Session start

Goal: upgrade the Supplementary §S4 Balanced-near-complement conjecture
into a proven Proposition, conditional on empirical coverage of all 10
observed near-complement cases.

Base version: v2.1.12.

Stages planned: S1 coverage check (mandatory) → branch on verdict.

## 2026-04-19 22:35 KST — S1 coverage-check script

First draft of `code/scripts/near_complement_coverage_check.py` invoked
`src.policy_simulator.run_with_policy`, which internally calls
`reconstruct_F + compute_coalition_costs` and enumerates all 2^n subsets
of F. For n=15 k=n cases (7 of 10) that is 2^15-1 = 32 767 subsets with
Held–Karp on each — infeasible in reasonable time. Killed after ~3 min.

Rewrote the script to invoke a lightweight copy of the event loop that
returns (arrivals, serve_times, C_N, k) only, then explicitly builds the
B_{n-1} ∪ B_{n-2} collection, checks feasibility via paper Def. 2
(max a_i < min s_i), and computes c(S) by Held–Karp only on that
O(n^2)-sized collection plus c*(N). This is 136 TSP calls per n=15
instance instead of 32 767.

## 2026-04-19 22:40 KST — S1 coverage verdict

Script ran in ~75 s total on the 10 cases:

```
  n  pattern    seed         r   r_diamond  fires  |Bn1∩F|  |Bn2∩F|   t(s)
 10  A           123    1.0529    1.048969    YES       10       45    0.3
 10  B_heavy     256    1.1261    1.047974    YES       10       45    0.1
 10  C           123    1.1238    1.048969    YES       10       45    0.1
 15  A            42    1.0475    1.049458    no        15      105   10.4
 15  A            99    1.0507    1.040182    YES       15      105   10.6
 15  A           123    1.0749    1.041439    YES       15      105   10.4
 15  B_heavy       7    1.1849    1.042080    YES       15      105   10.6
 15  C            42    1.0680    1.049458    YES       15      105   10.6
 15  C            99    1.1476    1.040182    YES       15      105   10.5
 15  C           123    1.1406    1.041439    YES       15      105   10.5
Coverage: 9 / 10 cases fire (r > r^♦).
```

Verdict: **9/10 in the 7–9/10 bracket**. Per the spec, proceed to STAGE 2
as a **partial theorem**: the proposition is mathematically correct
(Bondareva–Shapley direction is a clean contradiction argument); empirical
coverage is 9/10 on the observed near-complement cases. The one uncovered
case is (n=15, pattern=A, seed=42) with r=1.0475 and r^♦=1.049458
(fails the strict inequality by approximately 0.002). In every case, both |B_{n-1} ∩ F| = n and
|B_{n-2} ∩ F| = n(n-1)/2 — i.e., the full B_{n-1} ∪ B_{n-2} collection
is feasible for all 10 cases (k = n everywhere), so the proposition's
feasibility hypothesis is met on all 10; what fails for (15, A, 42) is
the threshold inequality, not the feasibility.

STAGE 2 approach: promote as Proposition with a clean statement; report
empirical fire-count honestly (9/10) in §6.4; keep the residual 1 case
classified as "near-complement not covered by the proposition".

## 2026-04-19 23:05 KST — S2 Proposition drafted

Placed as `\begin{proposition}[Balanced-near-complement threshold]` after
Remark~14 (`rem:near-complement`) in main.tex §5.1. Label
`prop:balanced-near-complement`. Numbering side effect: Observation 15 →
Observation 16, Theorem 16 → Theorem 17, Remark 17 → Remark 18,
Proposition 18 → Proposition 19, Corollary 19 → Corollary 20 (all via
automatic \ref{} in main.tex; three literal "Observation~15" in
supplementary.tex manually updated to Observation~16).

Proof-sketch kept inline in main.tex; full proof expanded in Suppl. §S4
together with the coverage audit and seed-42 diagnostic.

Table 5 updated to 5-row decomposition: 37 + 11 + 9 + 1 + 9 = 67 ✓.

Page-budget tension: first rebuild hit 32 pages (2 over). Compressed:
(i) Proposition proof moved to Suppl. §S4, proof-sketch only in main;
(ii) Remark 14 shortened; (iii) Conclusion paragraph compressed;
(iv) §7(iii) near-complement residual compressed;
(v) Broader-directions / VRG paragraph compressed;
(vi) bibliography set to `\scriptsize` with `\bibsep=0pt plus 0.1ex`.
Final: main 30, supp 8, highlights 1.

## 2026-04-19 23:10 KST — S3 Self-audit

S3.1 Proof re-read:
  - Feasibility hypothesis $\F\supseteq B_{n-1}\cup B_{n-2}$ clearly
    implies every $S$ in the collection satisfies the Core stability
    inequality $\sum_{i\in S}x_i\le c(S)$. ✓
  - Balancing condition $\sum_{S\ni i}\lambda_S=1$ is achievable for
    every player $i$: under the feasibility hypothesis, each player
    appears in $(n-1)+\binom{n-1}{2}=\binom{n}{2}$ coalitions of the
    collection, non-zero for $n\ge 3$; an explicit witness is
    $\lambda_S=1/(n-1)$ on $B_{n-1}$, $\lambda_S=0$ on $B_{n-2}$. ✓
  - Sum-swap: $\sum_S\lambda_S\sum_{i\in S}x_i=\sum_{i\in N}x_i\sum_{S\ni i}\lambda_S$
    is Fubini on a finite double sum, valid unconditionally. ✓
  - Reduction to $\sum_{i\in N}x_i$ uses the balancing condition. ✓
  - Reduction to $r\,c^{\ast}(N)$ uses the Temporal Core efficiency
    equality $\sum_i x_i = C(N)_{\mathrm{online}}$, which is
    Definition~3 in the main manuscript. ✓
  - Final contradiction: hypothesis $r > r^{(\diamond)}(\lambda)$ contra
    derived $r \le r^{(\diamond)}(\lambda)$. Genuine contradiction, not
    tautology. ✓
  - $r^{(\diamond)}$ well-defined: defined per specific $\lambda$; the
    proposition's quantifier is "for some such $\lambda$", so statement
    and proof match. ✓

S3.2 Coverage re-run: two independent invocations of
`near_complement_coverage_check.py` — both report 9/10 with identical
per-case `r^(♦)` values. Stable.

S3.3 No gap revealed. Proceeding to version bump + response doc +
final gates.
