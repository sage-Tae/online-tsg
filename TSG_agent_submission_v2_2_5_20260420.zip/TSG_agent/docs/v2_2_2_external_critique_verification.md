# v2.2.2 External Critique Verification Report

**Scope.** Verification only. No modifications to `paper/`, `code/`, CSVs,
scripts, or other `docs/` files were made in preparing this report, and
no PDFs were rebuilt. This document exists solely to record what is
real, what is false, and what is already addressed in v2.2.2, so that
the human author can decide revision scope.

**Repository state read.** `paper/main.tex` (770 lines),
`paper/supplementary.tex` (266 lines), `paper/highlights.txt` (9 lines),
`paper/cover_letter.md` (104 lines), `paper/references.bib` (341 lines).

---

## Part 1 — Reference existence and content

### R1. Lyu, Lalla-Ruiz, Schulte (2025), EJOR 323(3):888–906

**Claim.** "The collaborative berth allocation problem with row-generation
algorithms for stable cost allocations." Uses row-generation for stable
cost allocation.

**Search evidence.** ScienceDirect
<https://www.sciencedirect.com/science/article/pii/S0377221724009925>
confirms:
- Authors: Xiaohuan Lyu, Eduardo Lalla-Ruiz, Frederik Schulte
- Journal: European Journal of Operational Research, Vol. 323(3),
  pp. 888–906, 2025
- Content snippet: "a new mathematical model for the collaborative
  berth allocation problem, a cooperative game considering the core
  and the nucleolus for stable cooperation, row generation providing
  exact core and nucleolus for NP-hard problems, and a general-purpose
  algorithm to obtain the nucleolus for combinatorial optimization."

**Verdict: VERIFIED.** Bibliographic fields and content match the critique.

**Draft BibTeX (for human review — not added to `references.bib`):**
```bibtex
@article{lyu2025berth,
  author  = {Lyu, Xiaohuan and Lalla-Ruiz, Eduardo and Schulte, Frederik},
  title   = {The collaborative berth allocation problem with row-generation algorithms for stable cost allocations},
  journal = {European Journal of Operational Research},
  volume  = {323}, number = {3}, pages = {888--906}, year = {2025},
  doi     = {10.1016/j.ejor.2024.12.031}
}
```

### R2. Chen, Wang, Meng (2023), Transportation Research Part B 173:119–141

**Claim.** "Cost allocation of cooperative autonomous truck platooning:
Efficiency and stability analysis." Dynamic stability + cost allocation
in vehicle context.

**Search evidence.** ScienceDirect
<https://www.sciencedirect.com/science/article/abs/pii/S0191261523000711>
confirms:
- Authors: Shukai Chen, Hua Wang, Qiang Meng
- Journal: Transportation Research Part B: Methodological, Vol. 173,
  pp. 119–141, 2023
- Content snippet: "investigates the cost allocation of cooperative
  autonomous truck (AT) platooning among carriers ... (i) efficiency:
  the total cost is allocated to each carrier without a budget deficit,
  and (ii) stability: all carriers find it beneficial to stay in the
  grand alliance and do not form sub-alliance."

**Verdict: VERIFIED.** Content is closer to static-stability
cooperative-game analysis in a vehicle context rather than "dynamic
stability" in the dynamic-TU-game sense; but the critique's broader
characterization (cost allocation + stability, vehicle platooning) is
accurate.

**Draft BibTeX (for human review):**
```bibtex
@article{chen2023platoon,
  author  = {Chen, Shukai and Wang, Hua and Meng, Qiang},
  title   = {Cost allocation of cooperative autonomous truck platooning: Efficiency and stability analysis},
  journal = {Transportation Research Part B: Methodological},
  volume  = {173}, pages = {119--141}, year = {2023}
}
```

### R3. Van Zon, Spliet, van den Heuvel (2021), "The effect of algorithm capabilities on cooperative games"

**Claim.** Discusses Core stability when $c(S)$ is computed heuristically.

**Search evidence.** RePEc listing
<https://ideas.repec.org/p/ems/eureir/135596.html>
confirms a working paper:
- Authors: Van Zon, Spliet, van den Heuvel
- Title: "The effect of algorithm capabilities on cooperative games"
- Venue: Econometric Institute Research Papers EI2021-02 (Erasmus
  School of Economics, Erasmus University Rotterdam) — NOT a peer-
  reviewed journal article in the search results returned.
- Content snippet: "cost-allocation problem ... companies ...
  collaborate by consolidating demand and combining delivery routes
  ... joint network vehicle routing game (JNVRG) ... row generation
  algorithm to either determine a core allocation for the JNVRG or
  show that no such allocation exists ... two main acceleration
  strategies."

**Content-match assessment.** The title "algorithm capabilities"
strongly aligns with the critique's framing (Core stability as a
function of algorithmic capability / $c(S)$ computation quality), but
the paper as retrieved is about the JNVRG and row generation, not
explicitly "Core stability when $c(S)$ is heuristic." The critique's
description is consistent in direction but not verified at the
sentence level from the abstract alone; the full paper should be
read before citing on this specific point.

A closely related, already-published reference exists on JNVRG and
row generation by the same authors: "The Joint Network Vehicle Routing
Game," *Transportation Science* 55(1):179–195, 2021 (DOI 10.1287/
trsc.2020.1008). The critique may have conflated these two works.

**Verdict: AMBIGUOUS.** Working paper exists under the exact title and
author list cited; however (i) it is a working paper, not a journal
article, and (ii) the critique's specific content claim ("Core stability
when $c(S)$ computed heuristically") is plausible from the title but
not verified from the abstract. Human should read the full working
paper before citing, and may prefer to cite the related *Transportation
Science* paper instead.

**Draft BibTeX (working paper; for human review):**
```bibtex
@techreport{vanzon2021algorithm,
  author      = {van Zon, Mart{\'\i}n and Spliet, Remy and van den Heuvel, Wilco},
  title       = {The effect of algorithm capabilities on cooperative games},
  institution = {Econometric Institute, Erasmus University Rotterdam},
  type        = {Econometric Institute Research Papers},
  number      = {EI2021-02},
  year        = {2021}
}
```

### R4. Zhang, Luo, Qin, Lim (2019), Transportation Science 53(2):427–441

**Claim.** "Exact Algorithms for VRP with Time Windows and Combinatorial
Auction." Auction + VRP + TW intersection.

**Search evidence.** Transportation Science listing via CityUHK Scholars
<https://scholars.cityu.edu.hk/en/publications/exact-algorithms-for-the-vehicle-routing-problem-with-time-window/>
confirms:
- Authors: Zhenzhen Zhang, Zhixing Luo, Hu Qin, Andrew Lim
- Full title: "Exact Algorithms for **the** Vehicle Routing Problem
  with Time Windows and Combinatorial Auction"
- Journal: Transportation Science, Vol. 53(2), pp. 427–441, March 2019
- DOI: 10.1287/trsc.2018.0835
- Content snippet: CNPC petroleum delivery; arc-flow and set-
  partitioning models; external 3PL bids selected via combinatorial
  auction; delivery via self-owned trucks under time windows.

**Verdict: VERIFIED.** Title differs by one word ("the") from the
critique; all other bibliographic fields and the auction+VRP+TW subject
match.

**Draft BibTeX (for human review):**
```bibtex
@article{zhang2019vrptw,
  author  = {Zhang, Zhenzhen and Luo, Zhixing and Qin, Hu and Lim, Andrew},
  title   = {Exact Algorithms for the Vehicle Routing Problem with Time Windows and Combinatorial Auction},
  journal = {Transportation Science},
  volume  = {53}, number = {2}, pages = {427--441}, year = {2019},
  doi     = {10.1287/trsc.2018.0835}
}
```

---

## Part 2 — Sanity checks on critique points

### C1. Abstract's last sentence "preserve Core stability"

**Current last sentence of abstract (main.tex:59, verbatim):**

> "A scale-up study to 50 customers confirms the asymptotic tightening,
> and the intermediate-coalition mechanism disappears under
> cheapest-insertion and batch re-optimization dispatch, suggesting
> that short service windows plus informed dispatch preserve Core
> stability."

**Assessment.** The sentence uses a hedged framing ("*suggesting* that
... preserve Core stability"), not a bare assertion ("preserve Core
stability"). However, the inner clause after the hedge still uses
"preserve," which is stronger than the critique's proposed
"substantially improve ... in our experiments." Reasonable editors may
differ on whether "suggesting that X preserve Y" is hedged enough.

**Verdict: TOO-STRONG (mildly).** Hedge word "suggesting" is present,
but the verb "preserve" is an overstatement of a 175-instance
empirical study. A softer wording (e.g., "*substantially improve* Core
stability in our experiments") would better match the evidence.

---

### C2. Observation 16 — theorem environment choice

**Current statement (main.tex:372–375, verbatim):**

> `\begin{observation}[Intermediate-coalition mechanism]`
> `\label{obs:intermediate}`
> "In 9 of the 175 main-grid instances under the NN policy, the
> Temporal Core is empty despite (i) the hypothesis of Theorem~...
> being vacuous ... and (ii) the hypothesis of Proposition~... being
> vacuous. All 9 satisfy $k<n-1$ and arise in patterns $B_{\text{medium}}$
> (7 cases) and E (2 cases) with realized competitive ratio
> $r\in[1.33,1.61]$. The binding constraints in the Core LP concentrate
> on intermediate-size coalitions ($2\le |S|\le n-3$) ... An analytic
> sufficient condition is open (Section~...)."

**Environment.** Defined at main.tex:35 as
`\newtheorem{observation}[theorem]{Observation}` (shares counter with
the theorem environment). This is a **standard** amsthm pattern in
many OR/game-theory journals.

**"Empirical Phenomenon" check.** "Empirical Phenomenon" is *not* a
standard amsthm environment in EJOR, Transportation Science,
Mathematical Programming, or INFORMS style guides. "Observation" is
the conventional name for an empirical/descriptive claim that is not
proved. Renaming to "Empirical Phenomenon" would be a stylistic
regression from journal convention.

**Split-into-two-conjectures check.** The paragraph makes exactly one
empirical claim (9 instances exhibit the intermediate-coalition
mechanism under NN, all at $k<n-1$, all in $B_{\text{medium}}$ or E).
It is already one statement; splitting into two conjectures would
fragment the evidence.

**Verdict: KEEP-AS-IS.** "Observation" is the correct environment;
no action.

---

### C3. Highlight bullet 3 "Tight emptiness threshold"

**Current `highlights.txt` (verbatim):**

```
Highlights

Online Traveling Salesman Games: Temporal Nucleolus and the Fragility of the Core under Dynamic Arrivals

- Online Traveling Salesman Game: coalitions restricted by arrival dynamics
- Temporal Nucleolus computed by sequential linear programming over this family
- Tight emptiness threshold for the complement-coalition mechanism
- Bounded customer queue structurally blocks all three complement-based mechanisms
- Threshold tightens to one at the classical square-root rate; tested to fifty
```

Bullet 3 has 56 characters (well under Elsevier's 85-character per-
bullet ceiling).

**"Sharp" vs "Tight" assessment.** Both terms are standard in
game-theoretic / threshold-bound literature. "Tight" is the more
common usage for Bondareva–Shapley-type sufficient conditions that
are witnessed by balanced collections attaining the bound; "Sharp"
is more common for rate bounds in asymptotic analysis. The current
paper uses both ("sharpest", "sharp structural claim", "tight" in
different contexts). No substantive technical distinction is at
stake; the change is purely cosmetic.

**Verdict: COSMETIC-ONLY.** The critique's rewrite is a matter of
taste, not a correctness issue.

---

### C4. Lemma 10 proof — chain "j* to l*-1" may include index i

**Note on numbering.** The main manuscript's theorem counter is
shared across lemma/theorem/proposition/corollary/observation/remark/
definition/example. Counting in document order: Def 1, Def 2, Def 3,
Example 4, Def 5, Prop 6, Rem 7, Rem 8, Lem 9, **Lem 10**, Thm 11,
Prop 12, Cor 13, Rem 14, Prop 15, Obs 16, Thm 17, Rem 18, Prop 19,
Cor 20. **Lemma 10** = "Fully sequential arrivals preclude
$N\setminus\{i\}\in\F$" (main.tex:291).

**Current proof (main.tex:296–298, verbatim):**

> "Fix $i$ and assume customers are indexed in arrival order
> $1,\ldots,n$ so that $a_1 \le \cdots \le a_n$. Let
> $\ell^{\star}=\max\{j:j\neq i\}$ and $j^{\star}=\min\{j:j\neq i\}$
> denote, respectively, the latest and earliest arrival-order indices
> other than $i$. By the sequential-arrival hypothesis $s_j \le
> a_{j+1}$ applied along the chain $j^{\star}, j^{\star}+1, \ldots,
> \ell^{\star}-1$, we obtain $s_{j^{\star}} \le a_{j^{\star}+1} \le
> s_{j^{\star}+1} \le \cdots \le a_{\ell^{\star}}$, hence
> $a_{\ell^{\star}} \ge s_{j^{\star}}$. Therefore $\max_{j\neq i} a_j
> \ge \min_{j\neq i} s_j$, violating the if-and-only-if criterion of
> Lemma~9."

**Indexing analysis.** The hypothesis "$s_j \le a_{j+1}$ for all
$j = 1, \ldots, n-1$" of Lemma 10 is stated over the full index set
$\{1,\ldots,n-1\}$ (equivalently, over $N\setminus\{n\}$), i.e. it is
**not** indexed over $N\setminus\{i\}$. Consequently the telescoping
chain $s_{j^\star} \le a_{j^\star+1} \le s_{j^\star+1} \le \cdots \le
a_{\ell^\star}$ is valid even if one of the intermediate indices
equals $i$: the hypothesis applies at every $j = j^\star, \ldots,
\ell^\star - 1$, regardless of whether $j = i$ or $j \ne i$. The
only requirement is that the terminal index $\ell^\star$ belongs to
$N\setminus\{i\}$ (to conclude $\max_{j \ne i} a_j \ge a_{\ell^\star}$)
and that the initial index $j^\star$ belongs to $N\setminus\{i\}$
(to conclude $\min_{j\ne i} s_j \le s_{j^\star}$), both of which hold
by construction.

**Verdict: GAP-ALREADY-HANDLED.** The critique misreads the scope of
the telescoping. The hypothesis is over $N$ (more precisely, over
$\{1,\ldots,n-1\}$), not $N\setminus\{i\}$, so the chain handles
the case where $i$ lies in the interior of the chain automatically.
A one-line clarification ("the hypothesis applies for every
$j=1,\ldots,n-1$, including $j=i$ if $j^\star < i < \ell^\star$")
could be added for reader convenience but is not required for
correctness.

---

### C5. Proposition 15 proof — "finite double sum" language

**Current Supplementary §S4 proof of Prop 15 (supplementary.tex:199–
215, verbatim):**

> "Suppose for contradiction that $x\in\mathrm{Core}(N,c,\mathcal{F})$.
> The feasibility hypothesis $\mathcal{F}\supseteq B_{n-1}\cup B_{n-2}$
> guarantees that for every $S\in B_{n-1}\cup B_{n-2}$ the Temporal
> Core stability inequality $\sum_{i\in S}x_i \le c(S)$ holds.
> Multiply (S4.1) by $\lambda_S\ge 0$ and sum over $S\in B_{n-1}\cup
> B_{n-2}$:
>   $\sum_{S}\lambda_S \sum_{i\in S}x_i \le \sum_{S}\lambda_S c(S)$.
> The left-hand side is a finite double sum; swapping the order of
> summation gives
>   $\sum_{S}\lambda_S \sum_{i\in S}x_i = \sum_{i\in N} x_i
>    \sum_{S\ni i}\lambda_S = \sum_{i\in N} x_i$,
> where the second equality uses the balancing condition
> $\sum_{S\ni i}\lambda_S=1$ for every $i\in N$. The Temporal Core
> efficiency equality gives $\sum_{i\in N} x_i = C(N)_{\mathrm{online}}
> = r\,c^{\ast}(N)$. Combining,
>   $r\,c^{\ast}(N) \le \sum_{S}\lambda_S c(S) = r^{(\diamond)}(\lambda)
>    \cdot c^{\ast}(N)$,
> i.e. $r\le r^{(\diamond)}(\lambda)$, contradicting the hypothesis
> $r>r^{(\diamond)}(\lambda)$."

**Assessment.** The phrase "The left-hand side is a finite double sum"
is present, but it is immediately followed by the explicit reindexing
formula $\sum_{S}\lambda_S \sum_{i\in S}x_i = \sum_{i\in N} x_i
\sum_{S\ni i}\lambda_S$. The swap is written out, not merely asserted.

**Verdict: ALREADY-EXPLICIT.** The critique misses that the explicit
formula is given; the phrase "finite double sum" is introductory, not
a replacement for the formula. No action required.

---

### C6. Corollary 20 — "vacuous" terminology

**Current Corollary 20 (main.tex:439–446, verbatim):**

> "If the peak waiting queue satisfies $k=\max_t |U_t| < n-1$, then
> no coalition of the form $N\setminus\{i\}$ is feasible, so
> Theorem 11, Proposition 12, and Proposition 15 are each vacuous:
> none of their feasibility hypotheses can hold. The only remaining
> *a priori* mechanism for emptying the Temporal Core under $k<n-1$
> is Remark 7, which is dominated by $r^\ast$ and rarely binds in
> practice. Intermediate-coalition violations remain logically
> possible; their empirical frequency is characterized in Section 6."

**Usage assessment.** "A theorem is vacuous" meaning "its hypothesis
cannot be satisfied in the current setting, so it provides no
information" is standard mathematical usage (compare: "the universal
statement over an empty set is vacuously true"). The Corollary even
clarifies the intended meaning in the following clause ("none of
their feasibility hypotheses can hold"), so no reader can plausibly
mis-parse it.

**Verdict: STANDARD-USAGE.** No action required.

---

### C7. Theorem 17 — non-uniform distributions (Pattern C)

**Current hypothesis of Theorem 17 (main.tex:377–384, verbatim):**

> "Assume customer coordinates $x_1,\ldots,x_n$ are drawn i.i.d. from
> the **uniform distribution on $[0,L]^2$**, with the depot placed at
> the origin $(0,0)$. Suppose the arrival pattern is such that
> $N\setminus\{i\}\in\F$ for at least one index $i$. Then ..."

**Pattern C description.** The supplementary materials (§S1,
supplementary.tex:52) describe Pattern C as "the **clustered**
pattern C," and main.tex:205, 211 treat it as non-uniform in
experiments.

**Assessment.** The theorem's hypothesis is explicit that coordinates
are i.i.d. uniform on $[0,L]^2$, so Pattern C (clustered) is *not*
covered by the asymptotic statement. The critique's observation is
factually correct: the theorem does not address Pattern C. However,
this is a deliberate scoping choice, not a proof gap — the
Beardwood–Halton–Hammersley limit used in Step 2 of the proof
requires i.i.d. uniform. Clustered samples (mixtures of Gaussians,
spatial correlation) admit distinct scaling laws and would need a
separate theorem.

**Verdict: CRITIQUE-VALID (but not a defect).** The theorem is
correctly stated within its scope; extending to clustered/non-uniform
distributions is new work, not a correction. A one-sentence
scope-limitation remark after Theorem 17 would pre-empt the
reviewer's question without requiring new theory.

---

### C8. §3.2 — economic justification for efficiency = C(N)_online

**Current "Characteristic cost versus realized cost" paragraph
(main.tex:164, verbatim):**

> "The characteristic function $c(S)$ is the time-independent optimal
> TSP tour on $S\cup\{0\}$, matching the classical Potters et al.
> (1992) definition. The realized online tour cost $C(N)_{\text{online}}$,
> by contrast, is the total travel distance of the tour actually
> executed by the online dispatch policy, which may exceed $c^\ast(N)$
> because the online policy cannot anticipate future arrivals; in
> general $C(N)_{\text{online}} \ge c^\ast(N)$. **We use
> $\sum_i x_i = C(N)_{\text{online}}$ as the efficiency budget because
> this is the cost the platform must actually allocate**; the
> competitive ratio $r = C(N)_{\text{online}}/c^\ast(N)$ measures the
> overhead introduced by online dispatch, since the online policy
> must commit to visits without seeing future arrivals. The threshold
> $r^{\ast\ast}$ (Theorem 11) is a function of coordinate geometry
> alone through $c(\{i\})$, $c(N\setminus\{i\})$, and $c^\ast(N)$."

**Assessment.** The economic justification is present ("this is the
cost the platform must actually allocate"). It is concise but
substantive: the platform has to recover its operational cost from
customers, and that cost is the online-realized cost, not the
counterfactual offline optimum.

**Verdict: ALREADY-JUSTIFIED.** Expansion into a longer paragraph
citing budget-balance requirements in cooperative game theory is
possible but not required. No action unless the author chooses to
expand for reviewer clarity.

---

### C9. Goyal et al. (2025) — orthogonality explicitly spelled out?

**Citations found (main.tex):**

1. Line 69: "Recent work on online cooperative games (Ge et al. 2024;
   Aziz et al. 2025; Goyal et al. 2025) has begun to address
   temporality but not in the routing context."
2. Line 94: "Goyal et al. (2025) introduce Temporal Cooperative Games,
   in which the characteristic function is indexed by time."

**Departure paragraph (line 94).** "The online-game literature differs
from ours in two respects. First, Bullinger and Romen (2023) formalize
coalition *formation* ... rather than cost sharing within a fixed
grand coalition ... Second, and common to the whole stream, **none of
these models equip the online coalition process with a TSP or routing
cost structure**; the inequalities that define our Temporal Core
reflect exactly the geometric interactions among customers in the
plane..."

**Assessment.** The two-dimensional orthogonality claim (no routing
cost, and different strategic problem for Bullinger) is stated, but
the specific distinction between **Goyal's sequence-indexed $v(\pi)$**
and **our set-valued $c(S)$ over the restricted family $\mathcal{F}$**
is *not* explicitly stated. A reader has to infer from "characteristic
function is indexed by time" (Goyal) vs. Definition 3 (our $c$ is
indexed over subsets, admissibility indexed by $\mathcal{F}$). The
critique's claim is correct: the contrast is implicit.

**Verdict: IMPLICIT.** A one-sentence addition to the Departure
paragraph (e.g., "Specifically, Goyal et al. (2025) index the
characteristic function by time/sequence $v(\pi)$, whereas our $c$
remains set-valued on $2^N\setminus\{\emptyset\}$ with time entering
only through the admissibility family $\mathcal{F}$") would close the
gap. The critique is incorporate-worthy but minor.

---

### C10. Cover letter — reviewer suggestions

**Current `paper/cover_letter.md` (verbatim scan).** No section
labeled "Suggested reviewers," "Recommended reviewers," "Reviewer
suggestions," or equivalent. The closing structure is
"Declarations → Signature → Author-side placeholders," without a
reviewer-list section.

**Deliberate-omission check.** The author-side placeholders (lines
98–105) list only: submission date, corresponding e-mail, ORCIDs,
corresponding-author designation. No placeholder for suggested
reviewers. EJOR's submission system at
<https://www.editorialmanager.com/ejor/> collects suggested
reviewers as a separate on-submission field, not as a cover-letter
appendix; the omission from the cover letter is consistent with
EJOR practice. Prior session logs
(`docs/v2_2_1_to_v2_2_2_response.md:115–117`) record the cover-
letter structure as verified against the EJOR editorial-board page.

**Verdict: DELIBERATELY-OMITTED.** EJOR handles reviewer suggestions
via the editorial-manager form, not the cover letter; inclusion in
the letter would be redundant with the submission form. No action.

---

## Part 3 — Numerical timeline claims

### T1. EJOR review timeline 4–8 months vs TS 8–14 months

**Verdict: NOT VERIFIABLE** from the repository. Both estimates are
within the plausible range reported by recent public dashboards
(SciRev, Elsevier turnaround pages) for OR journals, with some
variation. No known fact contradicts either estimate, but
specific-month numbers are not verifiable here.

### T2. "Tae 2020 VRGTW was published in EJOR"

**Repository check.** `paper/references.bib` lines 136–141:

```
@article{tae2020vrgtw,
  author  = {Tae, Hyunchul and Kim, Byung-In and Park, Junhyuk},
  title   = {Finding the nucleolus of the vehicle routing game with time windows},
  journal = {Applied Mathematical Modelling},
  volume  = {80}, pages = {334--344}, year = {2020}
}
```

**Verdict: FALSE.** Tae et al. (2020) was published in *Applied
Mathematical Modelling*, volume 80, pp. 334–344 — **not** in EJOR.
The critique's claim is wrong. (Note: Park, Tae & Kim 2012 IS in
EJOR, but that is the school-bus routing paper, distinct from the
2020 VRGTW paper.)

### T3. Slowinski as EJOR Editor-in-Chief

**Prior verification.** `docs/v2_2_1_to_v2_2_2_response.md:115–117,
150–153` records that the cover-letter salutation "Prof. Roman
Słowiński, Co-ordinating Editor-in-Chief" was verified against the
EJOR / Elsevier editorial-board page during the v2.2.2 cycle.

**Verdict: PREVIOUSLY VERIFIED.** No contradiction observed;
re-verification at submission time is still prudent since editorial
boards change.

---

## Part 4 — Summary table and conclusions

### Summary: R1–R4

| Ref | Verdict | Recommended action |
|-----|---------|---------------------|
| R1 Lyu et al. 2025 EJOR | VERIFIED | May incorporate (draft BibTeX in §R1) — only if the revised text genuinely cites it |
| R2 Chen et al. 2023 TR-B | VERIFIED | May incorporate (draft BibTeX in §R2) — only if relevant to revision |
| R3 Van Zon et al. 2021 | AMBIGUOUS | NEEDS-HUMAN-DECISION — working paper exists under this title; content match is plausible but not verified at sentence level; consider citing "The Joint Network Vehicle Routing Game" (*Transp. Sci.* 2021) instead |
| R4 Zhang et al. 2019 TS | VERIFIED | May incorporate (draft BibTeX in §R4) — only if the revised text genuinely cites it |

### Summary: C1–C10

| Critique | Verdict | Recommended action |
|----------|---------|---------------------|
| C1 abstract "preserve Core stability" | TOO-STRONG (mild) | PARTIALLY INCORPORATE — soften to "substantially improve Core stability in our experiments" or similar |
| C2 Observation 16 rename/split | KEEP-AS-IS | REJECT — "Observation" is the standard environment; "Empirical Phenomenon" would be a regression |
| C3 highlights "Tight" → "Sharp" | COSMETIC-ONLY | REJECT — no technical distinction |
| C4 Lemma 10 proof gap | GAP-ALREADY-HANDLED | REJECT (optionally add one-line clarification for reader convenience) |
| C5 Prop 15 double-sum language | ALREADY-EXPLICIT | REJECT — the explicit reindexing formula is already present |
| C6 Cor 20 "vacuous" | STANDARD-USAGE | REJECT |
| C7 Thm 17 non-uniform distributions | CRITIQUE-VALID (scope) | PARTIALLY INCORPORATE — add a one-sentence scope-limitation remark; no new theory needed |
| C8 §3.2 economic justification | ALREADY-JUSTIFIED | REJECT (optionally expand one sentence for reviewer clarity) |
| C9 Goyal orthogonality implicit | IMPLICIT | INCORPORATE — add one sentence contrasting Goyal's sequence-indexed $v(\pi)$ with our set-valued $c$ over $\mathcal{F}$ |
| C10 cover-letter reviewer suggestions | DELIBERATELY-OMITTED | REJECT — EJOR handles via submission form |

### Summary: T1–T3

| Timeline claim | Verdict |
|----------------|---------|
| T1 EJOR 4–8 mo vs TS 8–14 mo | NOT VERIFIABLE (not contradicted by known facts) |
| T2 Tae 2020 VRGTW in EJOR | FALSE — actually in *Applied Mathematical Modelling* 80:334–344 |
| T3 Słowiński EJOR EiC 2026 | PREVIOUSLY VERIFIED (v2.2.2 cycle, editorial-board page) |

---

## Completion signals

**1. Report path.**
`docs/v2_2_2_external_critique_verification.md` (this file).

**2. Summary of all verdicts** (one-line per item):
- R1 VERIFIED • R2 VERIFIED • R3 AMBIGUOUS • R4 VERIFIED
- C1 TOO-STRONG (mild) • C2 KEEP-AS-IS • C3 COSMETIC-ONLY
- C4 GAP-ALREADY-HANDLED • C5 ALREADY-EXPLICIT • C6 STANDARD-USAGE
- C7 CRITIQUE-VALID (scope) • C8 ALREADY-JUSTIFIED
- C9 IMPLICIT • C10 DELIBERATELY-OMITTED
- T1 NOT VERIFIABLE • T2 FALSE (claim) • T3 PREVIOUSLY VERIFIED

**3. References that MUST NOT be cited as stated (FALSE or AMBIGUOUS).**
- **R3 (Van Zon, Spliet, van den Heuvel 2021):** AMBIGUOUS — a working
  paper by these authors under this exact title exists (Erasmus
  Econometric Institute EI2021-02), but (i) it is not a peer-reviewed
  journal article, and (ii) the critique's specific content claim
  ("Core stability when $c(S)$ computed heuristically") is not
  verified at sentence level from the abstract. Do **not** cite on
  that specific point without reading the full paper. If a closely
  related published source is desired, cite instead: **van Zon,
  Spliet, van den Heuvel (2021), "The Joint Network Vehicle Routing
  Game," *Transportation Science* 55(1):179–195, DOI 10.1287/
  trsc.2020.1008.**

*No outright-FALSE reference was offered by the critique; only the
timeline claim **T2** (Tae 2020 in EJOR) is outright false and should
not be propagated in any revised text.*

**4. Critique points ALREADY ADDRESSED in v2.2.2 (do NOT act on):**
- **C2** Observation 16 — already uses the standard `observation`
  environment; renaming to "Empirical Phenomenon" would regress from
  journal convention.
- **C3** Highlight bullet 3 — "Tight" is standard; change is cosmetic.
- **C4** Lemma 10 proof — the telescoping chain is valid regardless
  of whether $i$ lies in $\{j^\star,\ldots,\ell^\star-1\}$, because
  the sequential-arrival hypothesis is indexed over $N$, not
  $N\setminus\{i\}$.
- **C5** Proposition 15 proof in §S4 — the explicit reindexing
  $\sum_S \lambda_S \sum_{i\in S}x_i = \sum_{i\in N} x_i
  \sum_{S\ni i}\lambda_S$ is already written out in full.
- **C6** Corollary 20 "vacuous" — standard mathematical usage,
  clarified in situ by "none of their feasibility hypotheses can
  hold."
- **C8** §3.2 economic justification — present ("this is the cost
  the platform must actually allocate").
- **C10** Cover-letter reviewer suggestions — deliberately omitted,
  consistent with EJOR handling the list via the submission form.

---

**End of verification report.** No revision plan is proposed; the
human author will decide which VERIFIED findings (R1, R2, R4; C1, C7,
C9) warrant incorporation, after this report.
