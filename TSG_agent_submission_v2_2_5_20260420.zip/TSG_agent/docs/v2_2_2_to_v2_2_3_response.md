# v2.2.2 → v2.2.3 Response

**Scope.** External-critique polish informed by
`docs/v2_2_2_external_critique_verification.md`. Literature additions
and minor scope notes only — no new results, no proof changes, no
numerical or CSV changes, no figure regeneration.

The verification report identified the following actionable items:
three verified reference additions (R1 Lyu 2025 EJOR, R2 Chen 2023
TR-B, R3 corrected from a working paper to van Zon et al. 2021 TS
JNVRG), one theorem-scope clarification (C7), one explicit-
orthogonality sentence (C9), and one mild abstract softening (C1).
The other seven critique items (C2 KEEP-AS-IS, C3 COSMETIC-ONLY,
C4 GAP-ALREADY-HANDLED, C5 ALREADY-EXPLICIT, C6 STANDARD-USAGE,
C8 ALREADY-JUSTIFIED, C10 DELIBERATELY-OMITTED) were rejected as
per-spec and are untouched in v2.2.3.

## Patch summary

### P1 — Lyu, Lalla-Ruiz & Schulte (2025), *EJOR* 323(3):888–906

Verified via ScienceDirect
<https://www.sciencedirect.com/science/article/pii/S0377221724009925>.
Content: "a new mathematical model for the collaborative berth
allocation problem, a cooperative game considering the core and the
nucleolus for stable cooperation, row generation providing exact core
and nucleolus for NP-hard problems."

- `paper/references.bib`: new entry `lyu2025collaborative`.
- `paper/main.tex` §2.1 after the Tae 2020 / Arroyo 2024 citation:
  one new sentence added framing their coalition family as static
  (vessel identity) and contrasting with our arrival-dynamics
  restriction.

### P2 — Chen, Wang & Meng (2023), *TR-B* 173:119–141

Verified via ScienceDirect
<https://www.sciencedirect.com/science/article/abs/pii/S0191261523000711>.
Content: efficiency + stability of cost allocation for cooperative
autonomous truck platooning.

- `paper/references.bib`: new entry `chen2023cost`.
- `paper/main.tex` §2.1 after the P1 sentence: one short sentence
  flagging this as a related dynamic-vehicle cooperative game
  application.

### P3 — van Zon, Spliet & van den Heuvel (2021), *Transportation Science* 55(1):179–195

**Important correction.** The external critique originally cited this
author team's *working paper* "The effect of algorithm capabilities on
cooperative games" (Erasmus Econometric Institute EI2021-02). The
verification report re-identified the correctly-titled, peer-reviewed
counterpart: **"The Joint Network Vehicle Routing Game"**, TS 55(1):
179–195, DOI 10.1287/trsc.2020.1008. Re-verified via Transportation
Science listing
<https://pubsonline.informs.org/doi/10.1287/trsc.2020.1008>.

- `paper/references.bib`: new entry `vanzon2021joint`.
- `paper/main.tex` §2.2 after the Drechsel & Kimms (2010) citation
  in the nucleolus-LP-methodology paragraph: one sentence describing
  their row-generation algorithm for Core allocations as the closest
  static-coalition-family methodological precedent to our
  sequential-LP cascade over the time-induced $\mathcal{F}$.

### P4 — Theorem 17 scope clarification (C7)

Verification found that Theorem 17 is explicitly stated for i.i.d.
uniform coordinates, which does not formally cover Pattern C
(clustered) or other experimental patterns with non-uniform spatial
structure. A reviewer may ask whether the asymptotic $O(n^{-1/2})$
rate still applies.

- `paper/main.tex`: one sentence inserted immediately after the end
  of Theorem 17's proof (before Remark 18), noting that the i.i.d.
  uniform hypothesis is required for the BHH $\sqrt{n}$ scaling of
  $c^{\ast}(N)$ in Step 2, and that an analogous $O(n^{-1/2})$ rate
  holds for general absolutely continuous distributions via Steele's
  (1997) limiting-functional framework, with the hidden constant then
  density-dependent.

No new bibliographic entry is needed — `steele1997probability` is
already in `references.bib`.

### P5 — Goyal et al. (2025) orthogonality (C9)

Verification found that the existing Goyal et al. citation in §2.2
asserts their framework "indexes the characteristic function by time"
but does not explicitly contrast their sequence-indexed worth
$v(\pi)$ with our set-valued $c(S)$ on a restricted family
$\mathcal{F}$.

- `paper/main.tex` §2.2: one sentence added immediately after the
  existing Goyal et al. sentence, making the orthogonality explicit:
  their $v(\pi)$ is a function of the realized arrival sequence while
  their coalition structure remains the full power set, whereas ours
  keeps $c(S)$ set-valued (matching the static TSG exactly) and
  restricts the coalition family to $\mathcal{F}$.

### P6 — Abstract mild softening (C1)

Verification found that the abstract's final sentence — "suggesting
that short service windows plus informed dispatch preserve Core
stability" — uses the verb *preserve*, which overstates a
175-instance empirical finding.

- `paper/main.tex` abstract: the verb *preserve* is changed to
  *substantially improve ... in our experiments*. The hedge word
  "suggesting" is retained. Net delta: +5 words. Abstract remains
  within the EJOR 50–250-word band.

## Page-budget offsets

The six patches add approximately 200–220 words. To keep `main.pdf`
at the EJOR 30-page cap, the following previously-present prose is
trimmed:

1. §5.3 Discussion last paragraph ("In the language of queueing
   theory..."): the two-sentence paragraph is compressed to one short
   sentence (~50-word saving). The core content (Corollary 20 blocks
   complement mechanisms under $k<n-1$, intermediate-coalition and
   near-complement violations remain logically possible) is preserved
   and already restated in §1 Practical Implication and §7
   Conclusion.
2. §6.6 Sharpness last sentence ("Note that $r^{\ast\ast\ast}$
   averages across complements while $r^{\ast\ast}$ takes the
   minimum of $\delta_i$; ... 20 are outside the single-complement
   regime"): removed (~40-word saving). The comparison between
   single-complement and balanced-complement thresholds is already
   visible in Table 5 (57 vs 37 fires) and discussed earlier in the
   same paragraph.

Estimated net page impact: ≤ +50 words after offsets, likely absorbed
within paragraph-packing.

**Caveat — LaTeX toolchain unavailable in this environment.** The
pdflatex binary was not present on the execution host (TeX Live 2026
was referenced in a prior build log at `/usr/local/texlive/2026basic/`
but that path is absent here). Therefore `main.pdf`,
`supplementary.pdf`, and `highlights.pdf` were **NOT** rebuilt in
this iteration. The v2.2.2 PDFs on disk are stale. Before tagging
v2.2.3 or submitting, the human author must:

```bash
cd paper
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
pdflatex supplementary.tex && bibtex supplementary && pdflatex supplementary.tex && pdflatex supplementary.tex
pdflatex highlights.tex && pdflatex highlights.tex
pdfinfo main.pdf | grep Pages:      # must be ≤ 30
pdfinfo supplementary.pdf | grep Pages:
```

Then re-run `scripts/verify_zip_rebuild.sh <submission.zip>` on the
freshly-built package. If `main.pdf` exceeds 30 pages, further
trimming from §5.3 Discussion or §6.6 Sharpness is the documented
remediation.

## Items NOT actioned (per verification report)

| Critique | Verdict | Reason not actioned |
|----------|---------|---------------------|
| C2 | KEEP-AS-IS | `observation` is the standard theorem environment; "Empirical Phenomenon" is non-standard in EJOR |
| C3 | COSMETIC-ONLY | "Tight" and "Sharp" are both standard; no technical distinction |
| C4 | GAP-ALREADY-HANDLED | Lemma 10's telescoping hypothesis is indexed over $\{1,\ldots,n-1\}$, so the chain works even if $i$ lies between $j^\star$ and $\ell^\star-1$ |
| C5 | ALREADY-EXPLICIT | §S4 Prop 15 proof already writes $\sum_S\lambda_S\sum_{i\in S}x_i = \sum_{i\in N}x_i \sum_{S\ni i}\lambda_S$ explicitly |
| C6 | STANDARD-USAGE | "The theorem is vacuous" with "none of the feasibility hypotheses can hold" is standard mathematical usage |
| C8 | ALREADY-JUSTIFIED | §3.2 already reads "this is the cost the platform must actually allocate" |
| C10 | DELIBERATELY-OMITTED | EJOR collects suggested reviewers via the editorial-manager form, not the cover letter |

## Items that CANNOT be cited

From the verification report's Part 3 Timeline claims:

- **T2 (critique claim: "Tae 2020 VRGTW was published in EJOR")
  is FALSE.** The bib entry in `paper/references.bib` correctly
  records *Applied Mathematical Modelling* 80:334–344. No action
  needed; but the claim must not be propagated in the revised text.

- The original R3 citation ("The effect of algorithm capabilities
  on cooperative games", Erasmus EI2021-02 working paper) is
  intentionally **not** added to `references.bib`. The published
  JNVRG paper by the same author team is the correct substitute
  and is what `vanzon2021joint` actually cites.

## Version-bump mechanics

- `README.md`: header `**Current version: v2.2.3**`, Key-results
  header `v2.2.3`, Version-history block appended with v2.2.3 entry,
  Reproducibility-tags block updated (v2.2.2 entry relabelled
  `(intermediate)`, v2.2.3 entry appended as `(current)`).
- `REPRODUCIBILITY.md`: title updated to v2.2.3, Version field
  updated, three in-body `v2.2.2` references updated, Version-History
  block: v2.2.2 relabelled `(intermediate)`, v2.2.3 appended as
  `(current)`.
- `scripts/verify_doc_consistency.sh`: `CURRENT_VERSION` bumped to
  `v2.2.3`; stale-version regex extended from `v2\.2\.[01]` to
  `v2\.2\.[012]` so that v2.2.2 (previously current) is now flagged
  outside historical blocks.

## Gate status

- `scripts/verify_doc_consistency.sh`: expected to PASS after this
  iteration (no stale v2.2.0/v2.2.1/v2.2.2 labels outside historical
  blocks; no stale page-count, seed123-row, orphan-figures/, or
  retired-metric hits).
- `scripts/verify_zip_rebuild.sh`: **cannot be executed in this
  environment** (pdflatex absent). Must be re-run by the human
  author on a machine with TeX Live installed.

## Files changed

- `paper/main.tex` — abstract (P6), §2.1 (P1, P2), §2.2 (P3, P5),
  after Theorem 17 proof (P4), §5.3 Discussion (trim), §6.6
  Sharpness (trim).
- `paper/references.bib` — three new entries appended.
- `README.md` — header, key-results header, version history block,
  reproducibility-tags block.
- `REPRODUCIBILITY.md` — title, Version field, three in-body labels,
  Version History block.
- `scripts/verify_doc_consistency.sh` — CURRENT_VERSION and regex.
- `docs/v2_2_2_to_v2_2_3_response.md` — this file.

No changes to `supplementary.tex`, `highlights.{tex,txt}`,
`cover_letter.md`, any CSV in `code/results/` or
`code/experiments/logs/`, any figure PDF in `code/figures/`, any
`src/` file, or any prior `docs/*.md` entry.
