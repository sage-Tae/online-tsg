# v2.2.1 → v2.2.2 response

Phase-3 EJOR submission-polish patch. Presentation only — no new
theoretical or experimental work. All numerical results, Proposition 15
and its proof, Supplementary §S4, CSVs, code, and figures are unchanged.

## Summary

| Task | Scope | Status |
|---|---|---|
| T1 | Abstract / Highlights / Introduction consistency sweep | **Done** |
| T2 | Defensive single-vehicle scope demarcation (§7 and §1) | **Done** |
| T3 | `paper/cover_letter.md` for the EJOR submission portal | **Done** |
| — | Version bump v2.2.1 → v2.2.2 | **Done** |

## T1 — Abstract / Highlights / Introduction

### T1.1 Abstract

Already current at v2.2.1: the abstract describes "three complementary
sufficient conditions", "jointly certify 57 of them with no false
positives", "one near-complement case falls just below the sharpest
balanced-near-complement threshold", and "9 intermediate-coalition
cases operate outside every complement-based sufficient condition at
$k<n-1$". No stale "without analytic sufficient condition" language
for the near-complement cases. **No edit required.**

### T1.2 Highlights — 1 bullet updated

`paper/highlights.tex` and `paper/highlights.txt` bullet 4 updated to
include Proposition 15:

- Before: "Bounded customer queue structurally blocks both
  complement-based mechanisms"
- After:  "Bounded customer queue structurally blocks all three
  complement-based mechanisms"

Character count: 80 ≤ 85 (EJOR limit); still formula-free and
abbreviation-free. Bullets 1, 2, 3, 5 were already accurate and
remain unchanged.

### T1.3 Introduction — 1 parenthetical updated

§1 "Practical implication" parenthetical listed only Theorem 11 and
Proposition 12 as the mechanisms that $k<n-1$ eliminates; Proposition
15 was missing.

- Before: "…eliminates all complement-coalition empty-Core
  mechanisms (Theorem 11 and Proposition 12)."
- After:  "…eliminates all complement-coalition empty-Core
  mechanisms (Theorem 11, Proposition 12, and Proposition 15)."

C2 and C4 already listed all three from v2.2.0 and required no
change.

### T1.4 Final stale-language grep

```
grep -n "without analytic\|no analytic sufficient\|open for both\|lack analytic" \
     paper/main.tex paper/supplementary.tex paper/highlights.tex
```
returns **0 hits**.

## T2 — Defensive single-vehicle scope demarcation

### T2.1–T2.2 §7 "Broader directions" rewrite

The pre-v2.2.2 paragraph framed the single-vehicle setting
apologetically ("the most natural extension … is left to future
work"). The new paragraph frames it as a deliberate methodological
choice and announces a companion Online VRG manuscript:

> **Scope demarcation and Online VRG.** The single-vehicle scope
> is a deliberate methodological choice: it isolates the temporal
> coalition-feasibility structure of $\F$ from fleet-assignment
> confounds, and the three complement-based sufficient conditions
> rely on $c(S)$ being a single TSP tour cost for which the
> insertion identity $c(\{i\})+c(N\setminus\{i\})\ge\cstar(N)$
> holds. An *Online Vehicle Routing Game* combining $\F$ with
> multi-vehicle capacity … requires redefining $c(S)$ jointly with
> capacity and a fleet-assignment rule, under which that insertion
> identity can fail; this opens a separate agenda … that a
> companion manuscript will develop.

Length budget: ~125 words (the original was ~80 words). The extra
~45 words fit the 30-page budget after T2.4's compensating trim
(below).

### T2.3 §1 scope note

§1 "Structure" paragraph gained a one-sentence scope note so readers
are informed of the single-vehicle scope upfront:

> "The Online TSG is a single-vehicle cooperative game; this scope
> isolates the temporal coalition-feasibility structure of $\F$ from
> fleet-assignment confounds and is discussed further in
> Section~\ref{sec:conclusion} (where a multi-vehicle Online VRG is
> deferred to a companion manuscript)."

### T2.4 Page-budget compensation

After T2.1 and T2.3, `main.pdf` overflowed to 31 pages. The overflow
was absorbed by trimming one redundant paragraph in §6.6 "Sharpness"
that restated why $r^{\ast}$ has no cross-pattern variance — a
"secondary point worth noting" sentence already subsumed by the
paragraph above it. The trim removed a well-isolated sentence block,
not a substantive claim; no numerical value or theorem reference
was touched. After the trim, `main.pdf` is back at exactly 30 pages.

## T3 — Cover letter

**New file:** `paper/cover_letter.md` (579 words, ≤ 600 limit).

Structure follows the spec:
  (a) Salutation (Prof. Roman Słowiński, Co-ordinating Editor-in-Chief,
      verified via a web search of the EJOR editorial-board page);
      paper title, authors, corresponding-author placeholder;
      EJOR-precedent citations (Göthe-Lundgren et al. 1996; Helsgaun
      2000; Kimms & Kozeletskyi 2016; Nguyen & Thomas 2016;
      Guajardo & Jörnsten 2015; Tae, Kim & Park 2020 — all already
      in the paper's reference list).
  (b) Core contribution: three analytic sufficient conditions
      (Thm 11, Prop 12, Prop 15) collectively certifying 57/67 empty
      cases (85%); Corollary 20 structural obstruction; Theorem 17
      BHH-based asymptotic tightening.
  (c) Scope and methodological choice: single-vehicle is deliberate;
      Online VRG companion manuscript in preparation.
  (d) Reproducibility: `https://github.com/sage-Tae/online-tsg` (URL
      verified from `paper/main.tex` line 763 and README),
      `REPRODUCIBILITY.md` with version tags.
  (e) Suggested reviewers: **section omitted** per T3.3 — the
      author should add specific names only if confident about
      current affiliations.
  (f) Declarations: no conflict of interest; not under consideration
      elsewhere; all authors have approved.
  (g) Signature block for corresponding author.

### Author-side placeholders that require filling before submission

Inline placeholders in the letter (marked `[…]`):
1. Submission date.
2. Corresponding author's e-mail address.
3. ORCID identifiers for both authors.
4. The corresponding-author designation (letter currently names
   Hyunchul Tae as corresponding — confirm with authors).
5. Optional: reviewer names (currently omitted; authors may add
   3–5 specific names drawn from the paper's reference list if they
   wish).

No substantive facts are fabricated. The only editor-identification
assumption is "Roman Słowiński, Co-ordinating Editor-in-Chief",
verified via a web search of the Elsevier editorial-board page
(since 1999 to present). If the authors prefer a neutral
salutation, replace the first line with "Dear Editor,".

## Version bump and packaging

- `README.md`: v2.2.1 → v2.2.2 header, key-results block, version-
  history entry, Reproducibility-tags entry (v2.2.1 demoted to
  intermediate, v2.2.2 added as current).
- `REPRODUCIBILITY.md`: title, Paper Info, Data Files header,
  body version references, verify-gate label, Version History entry.
- `scripts/verify_doc_consistency.sh`: `CURRENT_VERSION=v2.2.2`;
  stale-version regex now flags v2.2.0 and v2.2.1 as stale.

## Invariants preserved

- Proposition 15 (`\begin{proposition}[Balanced-near-complement
  threshold]\label{prop:balanced-near-complement}…\end{proposition}`)
  and the inline proof sketch: byte-identical to v2.2.0.
- Supplementary §S4 full proof and coverage audit: byte-identical to
  v2.2.0.
- Table 5 row counts (37 + 11 + 9 + 1 + 9 = 67) unchanged.
- All numerical results (4.351 / 1.223 / 1.096; sharpness 3.56 / 3.97;
  Example 4 allocation) unchanged.
- CSVs under `code/experiments/logs/` and `code/results/` unchanged.
- Figures under `code/figures/` unchanged.
- `code/src/` and `code/scripts/near_complement_coverage_check.py`
  unchanged.

## Expected gate results

- `scripts/verify_zip_rebuild.sh`: PASS (main.pdf 30/30, supp 8,
  highlights 1, 0 undefined refs/cites).
- `scripts/verify_doc_consistency.sh`: PASS (current v2.2.2,
  main 30, supp 8, seed123 = 2; no stale labels).
