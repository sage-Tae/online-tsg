# v2.1.11 verification report

Read-only verification. No edits made to paper/, code/, references.bib,
README.md, REPRODUCIBILITY.md, or any docs/ file other than this report.

## CHECK V1 — Supplementary §S4 proof sanity

### V1.a Balancing condition statement — **PASS**

§S4 body (paper/supplementary.tex lines 197–205):

> "Let $B_{n-1}=\{N\setminus\{i\}: i\in N\}$, $B_{n-2}=\{N\setminus\{i,j\}: i\neq j\in N\}$,
> and suppose $\mathcal{F}\supseteq B_{n-1}\cup B_{n-2}$. Suppose further that there
> exist non-negative weights $\{\lambda_S\}_{S\in B_{n-1}\cup B_{n-2}}$ with
> $\sum_{S\ni i}\lambda_S=1$ for every $i\in N$. Define
> $r^{(\diamond)} := \sum_{S\in B_{n-1}\cup B_{n-2}}\lambda_S\,c(S) / c^{\ast}(N)$."

- Feasibility hypothesis explicit: "$\mathcal{F}\supseteq B_{n-1}\cup B_{n-2}$" (union of
  both size classes must be in $\F$). ✓
- Weights defined over concrete index set: "$\{\lambda_S\}_{S\in B_{n-1}\cup B_{n-2}}$". ✓
- Balancing equation well-posed: $\sum_{S\ni i}\lambda_S=1$ sums over all $S$ in
  $B_{n-1}\cup B_{n-2}$ containing $i$. Well-posed because each $\lambda_S$ is
  indexed by $S$ (not by size class), so multiplicities in $B_{n-1}$ (each player
  appears in $n-1$ of these) and $B_{n-2}$ (each player appears in $\binom{n-1}{2}$
  of these) are absorbed individually. ✓

### V1.b Sufficient-direction proof — **PASS**

§S4 lines 209–213:

> "$\sum_S\lambda_S\,c(S) \ge \sum_S\lambda_S\sum_{i\in S}x_i
> = \sum_{i\in N}x_i\cdot\sum_{S\ni i}\lambda_S = \sum_i x_i
> = C(N)_{\mathrm{online}} = r\,c^{\ast}(N)$, so $r\le r^{(\diamond)}$;
> contrapositively, $r>r^{(\diamond)}$ forces emptiness."

Step-by-step:
- Step 1 ($\sum \lambda_S c(S) \ge \sum \lambda_S \sum_{i\in S} x_i$): valid — multiply
  each core inequality $\sum_{i\in S} x_i \le c(S)$ by $\lambda_S\ge 0$ and sum.
- Step 2 (swap to $\sum_{i\in N} x_i \sum_{S\ni i}\lambda_S$): valid Fubini over
  the finite double sum.
- Step 3 (reduce to $\sum_i x_i$): uses balancing $\sum_{S\ni i}\lambda_S=1$ for
  every $i$. Valid.
- Step 4 (equate to $C(N)_{\mathrm{online}} = r\,c^{\ast}(N)$): uses the Temporal
  Core efficiency equality $\sum_i x_i = C(N)_{\mathrm{online}}$.
  **Critical check:** the reduction is to $C(N)_{\mathrm{online}}$ (= $r\,c^{\ast}(N)$)
  and not to $c^{\ast}(N)$ alone. The §S4 text explicitly writes
  "$=C(N)_{\mathrm{online}}=r\,c^{\ast}(N)$", so this is correctly handled. ✓
- Final: $r \le r^{(\diamond)}$; contrapositively, $r > r^{(\diamond)}$ forces
  $\mathrm{Core}=\emptyset$. Genuine contradiction with assumption $x\in\mathrm{Core}$,
  not a tautology. ✓

### V1.c Open-problem acknowledgement in §S4 — **PASS**

- Section title: "Open Problem: Balanced-near-complement threshold" (line 194).
- Labelled as "Conjecture" (line 207), not as Proposition/Theorem.
- §S4 contains a dedicated paragraph "Open empirical coverage question"
  (lines 215–219):
  > "The open question is whether $r^{(\diamond)}_{\min}$, computed as the
  > optimum of this LP, is sharp enough to cover the 10 observed
  > near-complement main-grid cases of Remark~14 (i.e., $r>r^{(\diamond)}_{\min}$
  > on all 10) without certifying emptiness in any of the 108 observed
  > nonempty-Core main-grid instances (no false positives). This
  > verification was flagged as out-of-scope for the present revision..."
- Acknowledgement of deferred empirical coverage is stated inside §S4
  itself (not only in docs/). ✓

## CHECK V2 — New references: hallucination and fit

### V2.1 Klijn & Slikker (2005) — **FAIL**

Bib entry (references.bib):
```
@article{klijn2005sequencing,
  author  = {Klijn, Flip and Slikker, Marco},
  title   = {Sequencing games with non-linear cost functions},
  journal = {Mathematical Methods of Operations Research},
  volume  = {62}, number = {1}, pages = {69--86}, year = {2005}
}
```

- **Venue TOC mismatch (FAIL).** DBLP listing for *Math. Methods of OR*
  vol 62 issue 1 (Sep 2005) (fetched via WebFetch) contains 10 articles;
  none is by Klijn & Slikker or has the title "Sequencing games with
  non-linear cost functions". Pages 69–86 in that issue are not assigned
  to any Klijn/Slikker paper (the 55–75 and 77–97 ranges bracket pp. 69–86,
  i.e., 69–86 straddles two unrelated papers: Gajrat & Hordijk and
  Glazebrook & Punton).
- **Author collaboration check (FAIL).** DBLP profile for Flip Klijn shows
  no Klijn–Slikker joint paper in 2005; their earliest joint work listed
  is 2019 ("A selfish allocation heuristic in scheduling" in EJOR).
- **Similar-title confusion:** a real paper exists with the closely related
  title "Sequencing situations and games with non-linear cost functions
  under optimal order consistency" (Schouten, Saavedra-Nieves,
  Fiestras-Janeiro), but it is 2021, EJOR, not Klijn/Slikker 2005.
- In-text citation (main.tex line 94): "Klijn & Slikker (2005) analyze
  sequencing games where arrival order can render coalitions infeasible,
  an admissibility principle we adapt to the metric TSP under an online
  arrival-service process rather than a fixed permutation." The content
  claim is plausible for the sequencing-games literature in general but
  cannot be validated because the cited paper does not exist as specified.

**Verdict: FAIL — the reference as cited appears to be hallucinated; the
  paper does not exist in the listed venue/volume/issue/pages.**

### V2.2 Platz & Hamers (2015) — **PASS**

Bib entry:
```
@article{platz2015multidepot,
  author  = {Platz, Trine Tornøe and Hamers, Herbert},
  title   = {On games arising from multi-depot {C}hinese postman problems},
  journal = {Annals of Operations Research},
  volume  = {235}, number = {1}, pages = {675--692}, year = {2015}
}
```
Tilburg University Research Portal and Springer (DOI 10.1007/s10479-015-1977-3)
confirm: authors Trine Tornøe Platz and Herbert Hamers, Annals of OR, vol 235
issue 1, pp. 675–692, 2015. All fields match.

In-text (main.tex line 91): "Platz & Hamers (2015) extend the routing-plus-
cooperative-game template to multi-depot Chinese postman problems, but with
coalition family $2^N$ rather than a time-restricted $\F$." Paper's abstract
confirms it treats MDCPP cooperative games on the full player set (2^N coalition
family is accurate). Claim is an accurate summary. ✓

### V2.3 Özener & Ergun (2008) — **PASS**

Bib entry:
```
@article{ozener2008allocating,
  author  = {Özener, Okan Örsan and Ergun, Özlem},
  title   = {Allocating costs in a collaborative transportation procurement network},
  journal = {Transportation Science},
  volume  = {42}, number = {2}, pages = {146--165}, year = {2008}
}
```
INFORMS PubsOnline confirms: Transportation Science, Vol. 42, No. 2, pp. 146–165,
2008; DOI 10.1287/trsc.1070.0219. All fields match.

In-text (main.tex line 91): "Özener & Ergun (2008) treat operational cost
allocation among carriers in a collaborative transportation procurement network
with a fixed carrier set." Paper's abstract confirms: shippers collaborate,
bundled shipment requests; fixed collaboration set. Claim is accurate. ✓

### V2.4 Drechsel & Kimms (2010) — **FAIL**

Bib entry:
```
@article{drechsel2010computing,
  author  = {Drechsel, Julia and Kimms, Alf},
  title   = {Computing core allocations in cooperative games
             with an application to cooperative procurement},
  journal = {Computers \& Industrial Engineering},
  volume  = {59}, number = {4}, pages = {547--555}, year = {2010}
}
```

- **Title authentic:** A paper by Drechsel & Kimms with exactly this title
  and year does exist.
- **Venue WRONG (FAIL).** The paper was published in *International Journal
  of Production Economics*, vol 128, no 1, pp. 310–321, November 2010
  (ScienceDirect pii: S0925527310002689; IDEAS/RePEc:
  ideas.repec.org/a/eee/proeco/v128y2010i1p310-321.html).
  Not *Computers & Industrial Engineering*.
- **Pages WRONG.** The correct range is 310–321, not 547–555.
- **C&IE 59(4) cross-check:** WebFetch of the Computers & Industrial
  Engineering vol 59 issue 4 TOC shows no Drechsel/Kimms paper; pages
  547–555 in that issue are occupied by unrelated papers (Ji & Xia
  "Analysis of vehicle requirements…" at 544–551).
- In-text (main.tex line 94): "a Core-targeted LP methodology for
  cooperative procurement in Drechsel & Kimms (2010) that serves as an
  early precedent for the constraint-generation style we adapt to $\F$."
  The content claim is accurate to the actual paper; the bibliographic
  coordinates are not.

**Verdict: FAIL — venue, volume, issue, and page range are all incorrect.
The paper exists but at a different venue; the bib entry as shipped would
mislead a reader attempting to retrieve the source.**

### V2.5 Özener, Ergun & Savelsbergh (2013) — **PASS**

Bib entry:
```
@article{ozener2013allocating,
  author  = {Özener, Okan Örsan and Ergun, Özlem and Savelsbergh, Martin},
  title   = {Allocating cost of service to customers in inventory routing},
  journal = {Operations Research},
  volume  = {61}, number = {1}, pages = {112--125}, year = {2013}
}
```
IDEAS/RePEc (inm/oropre/v61y2013i1p112-125) and Savelsbergh's Georgia Tech
preprint page confirm: Operations Research, vol 61, no 1, pp. 112–125,
February 2013. All fields match.

In-text (main.tex line 91): "Closest in spirit to our work, Özener et al.
(2013) combine routing, cost allocation, and a temporal dimension in
inventory routing; their temporality is a deterministic replenishment
schedule rather than an online stochastic arrival process restricting $\F$."
Paper's abstract confirms VMI inventory-routing cost allocation with a
fixed replenishment schedule; claim is an accurate summary and a correct
departure statement. ✓

## CHECK V3 — Detection-limit arithmetic

### V3.a Passage location — located

main.tex line 700 (Finding 3(b)):
> "no intermediate-coalition violation is observed in our sampled
> restricted-LP of $10^{4}$ coalitions per instance. This is a one-sided
> certificate only: the sampled LP cannot conclude full Core nonemptiness,
> and the sampling fraction $10^{4}/(2^{n}-1)$ collapses as $n$ grows
> ($\approx 10^{-2}, 10^{-5}, 10^{-11}$ at $n=20,30,50$; see detection-
> limit caveat below), so detection power decreases sharply."

main.tex line 702 (Detection-limit caveat):
> "The per-draw miss probabilities in Finding~3(b)---$\approx 1-10^{-2}/10^{-5}/10^{-11}$
> at $n=20/30/50$---are *detection-limit statements only*: they do not
> bound the probability of empty Core, only the probability that a single
> fixed binding coalition is in our sample."

### V3.b Arithmetic — **PASS**

Recomputation of $10^4/(2^n-1)$:
- $n=20$: $10^4/(2^{20}-1) = 10^4/1\,048\,575 = 9.537\times 10^{-3}$ ≈ $10^{-2}$.
- $n=30$: $10^4/(2^{30}-1) = 10^4/1\,073\,741\,823 = 9.313\times 10^{-6}$ ≈ $10^{-5}$.
- $n=50$: $10^4/(2^{50}-1) = 10^4/1.1259\times 10^{15} = 8.882\times 10^{-12}$ ≈ $10^{-11}$.

Paper's rounding:
- $9.54\times 10^{-3}$ → $10^{-2}$ (rounds up by factor ≈ 1.05 in log; essentially
  nearest order of magnitude). OK.
- $9.31\times 10^{-6}$ → $10^{-5}$ (rounds up by factor ≈ 1.07 in log; nearest
  order of magnitude). OK.
- $8.88\times 10^{-12}$ → $10^{-11}$ (rounds up by factor ≈ 1.05 in log; nearest
  order of magnitude). OK.

All three approximations are to the nearest order of magnitude; the direction
is consistently *up* (paper's stated floor is slightly looser than reality,
which is conservative for a detection-limit caveat — paper is not overstating
detection power).

### V3.c Framing — **PASS**

Quoting framing sentences:
- Finding 3(b): "*This is a one-sided certificate only: the sampled LP cannot
  conclude full Core nonemptiness*, and the sampling fraction … collapses."
- Detection-limit caveat: "*detection-limit statements only: they do not
  bound the probability of empty Core, only the probability that a single
  fixed binding coalition is in our sample*."

Framing is explicit and correct: detection-limit, not a Core-nonemptiness
bound.

**Verdict V3: PASS** (arithmetic correct to nearest order of magnitude; framing
explicit as detection-limit only).

## CHECK V4 — Downgrade propagation

### V4.a Repository grep — **PASS**

```
grep -rn "Theorem 6\|Theorem 18\|Thm\. 6\|Thm\. 18\|Thm 6\|Thm 18" \
  paper/ README.md REPRODUCIBILITY.md docs/
```
Hits and classification:
- `README.md:23` — v2.1.11 version-history entry describing the downgrade.
  **EXPECTED** (describes the change).
- `README.md:93` — Reproducibility-tags block, describes v2.1.11 change.
  **EXPECTED** (describes the change).
- `REPRODUCIBILITY.md:248` — Version History v2.1.11 entry describing the
  downgrade. **EXPECTED** (describes the change).
- `docs/v2_1_10_to_v2_1_11_response.md:12,39,40` — current response doc,
  describes the rename. **EXPECTED**.
- `docs/v2_1_3_to_v2_1_4_response.md:97`,
  `docs/v2_1_4_to_v2_1_5_response.md:101`,
  `docs/v2_1_5_to_v2_1_6_response.md:87`,
  `docs/v2_1_6_to_v2_1_7_response.md:139`,
  `docs/v2_1_7_to_v2_1_8_response.md:181`,
  `docs/v2_1_8_to_v2_1_9_response.md:155`,
  `docs/v2_1_9_to_v2_1_10_response.md:203` — historical response docs
  from prior iterations, phrased "Theorem 6, 11, 14, 16, 18 statements +
  proofs: unchanged" in the context of describing *that* version.
  **EXPECTED** (historical archive).
- `docs/review_response_summary.md:139`, `docs/phase3_complete_report.md:153`
  — phase/review summary artifacts from earlier revisions.
  **EXPECTED** (historical archive).

Zero STALE hits.

### V4.b Label renaming — **FAIL (intentional deviation)**

```
grep -rn "\\\\label\{thm:(static|reduction|inheritance|core-inheritance|static-equiv)" paper/
  → paper/main.tex:252: \label{thm:static-equiv}
  → paper/main.tex:412: \label{thm:core-inheritance}
```

Both labels remain at the `thm:` prefix rather than being renamed to `prop:`.
All `\ref{thm:static-equiv}` and `\ref{thm:core-inheritance}` references
(e.g., main.tex lines 75, 486, 488, 724) continue to target these `thm:`
labels. Cross-references compile and render correctly (PDF evidence in V4.c).

Strict reading of V4.b ("Verify the label has been renamed to prop:...")
is not satisfied. However, this is an **intentional deviation** documented
in `docs/v2_1_10_to_v2_1_11_response.md` (lines 4–6 and 28–31): the outer
v2.1.11 task spec explicitly states
  "Preserve every existing Theorem/Proposition/Corollary/Remark/Observation
  label that downstream code or docs reference, unless Tier 1 Task 1 below
  explicitly renames it"
and T1.1 does not explicitly specify label renaming. The v2.1.11 response
doc treats "label preserved" as the conservative interpretation of the
outer preservation rule.

**Verdict V4.b: FAIL by strict V4.b wording; the labels were intentionally
preserved for downstream cross-reference compatibility per the documented
rationale. No ref/label mismatches exist inside paper/main.tex.**

### V4.c Declaration environment + PDF rendering — **PASS**

`paper/main.tex:251`:
```
\begin{proposition}[Reduction at simultaneous arrivals]
\label{thm:static-equiv}
```
`paper/main.tex:411`:
```
\begin{proposition}[Inheritance of Static Core stability]
\label{thm:core-inheritance}
```

PDF rendering (pdftotext via pypdf):
- Page 2 (Introduction C1): "…the realized tour is optimal (**Proposition 6**)."
- Page 10 (§4.3 title): "**Proposition 6**(Reduction at simultaneous arrivals).
  Suppose $a_1 = a_2 = \cdots = a_n$…"
- Page 14 (§5.2): "**Proposition 18**(Inheritance of Static Core stability).
  If $C(N)_{\mathrm{online}} = c^*(N)$…"
- Page 16 (§6.2 title): "6.2 Verification of **Proposition 6**".
- Page 27 (§7(i)): "Theorem 11, **Proposition 18**, and Corollary 19 use
  only the realized tuple $(r,\mathcal{F},k)$…"

No occurrences of "Theorem 6" or "Theorem 18" in the compiled PDF.

## CHECK V5 — Page count and §S4 content budget

### V5.a pdfinfo / page counts — **PASS**

`pdfinfo` equivalent (pypdf PdfReader):
- paper/main.pdf — 30 pages (≤ 30 EJOR cap). ✓
- paper/supplementary.pdf — 7 pages (expected 7). ✓

### V5.b §S4 page budget — **PASS**

§S4 starts at character 511 of supplementary.pdf page 6 (the heading
"S4 Open Problem: Balanced-near-complement threshold") and the §S4 text
runs to the end of page 6. Page 7 contains only the "References" section
(170 characters total, one bibliography entry visible).

Per-page char counts: [1822, 1988, 1514, 2155, 1439, 1903, 170].

§S4 therefore occupies roughly the bottom 2/3 of page 6 plus zero content
on page 7 (page 7 is effectively bibliography). §S4 well under 1.5 pages.

Cross-check against v2.1.10 supplementary (6 pages): the References section
previously fit on page 6; adding §S4 to the end of the section content
pushed References onto a new page 7. Total delta = +1 page, attributable
entirely to §S4. No evidence §S1/§S2/§S3 lost material (Table S2, Table S3,
Table S1, Figure S1 all present in the current supplementary.pdf at their
expected locations).

## CHECK V6 — Empirical numbers retained unchanged

### V6.a Table 5 four-mechanism counts — **PASS**

CSV tally of `code/experiments/logs/policy_comparison_v2_full.csv`
filtered to `policy == 'nearest_neighbor'` (175 rows):
```
single_complement       37
balanced_complement     11
near_complement         10
intermediate             9
core_nonempty          108
total empty             67  (37 + 11 + 10 + 9)
total nonempty         108
```

main.tex line 503 (Table 5):
```
Single-complement ...       37 / 0 /  37
Balanced-complement ...     11 / 0 /  11
Near-complement ...         10 / 0 /  10
Intermediate ...             9 / 0 /   9
No mechanism predicts        0 / 108 / 108
Total                       67 / 108 / 175
```
Matches CSV tally exactly. ✓

Same counts repeated in abstract line 59, C4 line 78, Conclusion line 718.
All identical. ✓

### V6.b Example 4 TNu allocation — **PASS**

main.tex line 209:
```
(x_1, x_2, x_3, x_4, x_5) = (16.67, 20.51, 11.27, 15.18, 16.44),
```
Matches the v2.1.10 value verbatim.

### V6.c "1.81" removed from Example 4 — **PASS**

`grep -n "1\.81"` over paper/main.tex: **no hits**.

Current Example 4 text (main.tex line 205):
> "…Theorem~\ref{thm:empty-core} is vacuous: *no* complement coalition
> $N\setminus\{i\}$ is feasible, so $r^{\ast\ast}$ is undefined here
> because the minimum in its definition is taken over the empty set.
> The inequality $r > r^{\ast\ast}$ is thus not testable and
> Theorem~\ref{thm:empty-core} makes no prediction on this instance."

The illustrative numerical construction (which previously produced the
"≈ 1.81" ratio) has been removed; the qualitative explanation remains.

### V6.d r̄* / r̄** / r̄*** (4.351 / 1.223 / 1.096) — **PASS**

- main.tex line 78: "$\bar r^{\ast\ast}=1.223$, $\bar r^{\ast\ast\ast}=1.096$…
  classical bound ($\bar r^{\ast}=4.351$)".
- main.tex line 585 (Table 6 caption): "$\bar r^{\ast}$ … identical across
  all patterns at $4.351$".
- main.tex line 600 (Table 6 Overall row): "1.223 (0.121) & 1.096".
- main.tex line 621: "$\bar r^{\ast\ast}=1.223$ and $\bar r^{\ast\ast\ast}=1.096$
  versus $\bar r^{\ast}=4.351$".
- main.tex line 718 (Conclusion): "mean $\bar r^{\ast\ast}=1.223$…mean
  $\bar r^{\ast\ast\ast}=1.096$".

All 5 occurrences match. ✓

### V6.e Sharpness factors (3.56, 3.97) — **PASS**

- main.tex line 78: "sharper than the classical bound … by factors of
  $3.56$ and $3.97$".
- main.tex line 621: "$r^{\ast}/r^{\ast\ast} \approx 3.56$ and
  $r^{\ast}/r^{\ast\ast\ast} \approx 3.97$".
- main.tex line 718 (Conclusion): "a factor of $3.56$ relative to
  $r^{\ast\ast}$…and $3.97$ relative to $r^{\ast\ast\ast}$".

All three occurrences match. ✓

## CHECK V7 — Tone-down of B_medium nonemptiness claim

### V7.a Structural / empirical separation — **PASS**

main.tex line 696 (Finding 3 heading): "Pattern $\text{B}_{\text{medium}}$
blocks the complement mechanism structurally at every scale;
intermediate-coalition violations are not detected in the sampled LP
but cannot be ruled out."

- Finding 3(a) (line 698) explicitly labelled "*(a) Structural claim
  (analytic, strong).*"
- Finding 3(b) (line 700) explicitly labelled "*(b) Empirical observation
  (one-sided, weak).*"

Clear separation. ✓

### V7.b No "Core is nonempty" assertion — **PASS**

Quoted phrases in Finding 3 / §7(ii) / Summary:
- "blocks the complement mechanism structurally";
- "complement-based mechanisms … are structurally blocked by Corollary~19,
  regardless of the realized $r$";
- "no intermediate-coalition violation is observed in our sampled
  restricted-LP";
- "This is a one-sided certificate only: the sampled LP **cannot
  conclude full Core nonemptiness**";
- "Absence of observed violation at $n=50$ is therefore **not evidence of
  rarity**";
- §7(ii) line 726: "this limits the $\text{B}_{\text{medium}}$ nonemptiness
  claim to a structural statement … plus a one-sided empirical observation
  …, **not a proof of full Core nonemptiness**";
- Summary line 713: "The reading is: one strong analytic conclusion
  (structural blocking) plus one weak empirical one (no sampled violation)".

No assertion of Core nonemptiness as a proven fact at $n\in\{20,30,50\}$.
All phrasings are hedged as one-sided / structural / observational. ✓

### V7.c Detection-limit caveat present and cross-referenced — **PASS**

- Caveat paragraph exists at main.tex line 702:
  "**Detection-limit caveat.** The per-draw miss probabilities in
  Finding~3(b)…are *detection-limit statements only*…"
- Cross-referenced from Finding 3(b) (line 700): "see detection-limit
  caveat below".
- Cross-referenced from Summary (line 713): "detection-power limited
  (Finding~3(b))".
- Cross-referenced from §7(ii) (line 726): "Section~\ref{ssec:scaleup},
  detection-limit paragraph".

## CHECK V8 — Response doc faithfulness

### V8.a Task → source match — **PASS**

Spot-checks (3 tasks):

- **T1.1.** Response doc claims "`\begin{theorem}[Reduction at simultaneous
  arrivals]` → `\begin{proposition}`; label `thm:static-equiv` preserved".
  Source: main.tex line 251 is `\begin{proposition}[Reduction at simultaneous
  arrivals]`; line 252 is `\label{thm:static-equiv}`. Matches. ✓

- **T1.6.** Response doc claims Theorem 16 rewritten to
  "uniformly over the subclass of arrival patterns for which
  $\{i \in N : N\setminus\{i\}\in\F\}$ is non-empty." Source: main.tex
  line 364 reads verbatim the claimed clause. Proof closing sentence
  (line 392) matches the claimed update. ✓

- **T2.1.** Response doc claims "Fell back to open-problem statement…
  Keep Remark 14 as-is in main.tex… Supplementary §S4 added: the full
  statement, Bondareva–Shapley one-line direction, explicit open
  coverage question." Source: Remark 14 in main.tex unchanged;
  supplementary.tex §S4 (lines 194–219) present with the three
  components (hypothesis+threshold, Conjecture, Bondareva–Shapley
  direction, Open empirical coverage question). ✓

- Bonus check — **T2.2.** Response doc claims detection-limit
  quantification is integrated into §6.8 Finding 3(b) and a caveat
  paragraph. Source: main.tex lines 700 (Finding 3(b)) and 702
  (Detection-limit caveat) contain the expected quantifications. ✓

### V8.b T2.1 labelled "FELL BACK" honestly — **PASS**

- Response doc summary table row 19: status column reads
  "**Fell back to open-problem statement**".
- Response doc §T2.1 (line 153): "**Outcome: Fell back to open-problem
  statement.**"
- Supplementary §S4 presents the result as an "Open Problem" (section
  title, line 194) and a "Conjecture" (line 207); the Bondareva–Shapley
  direction is explicitly a half-proof (only the sufficient direction;
  the empirical coverage question is flagged open). §S4 does NOT present
  the result as a proved Proposition. ✓
