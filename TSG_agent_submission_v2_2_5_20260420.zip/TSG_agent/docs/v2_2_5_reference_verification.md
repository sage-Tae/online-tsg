# references.bib verification report (v2.2.5)

## Header

- Total entries: 46
- PASS: 39
- WARN: 7
- FAIL: 0
- NETWORK UNAVAILABLE: 0
- INCONCLUSIVE: 0
- Timestamp: 2026-04-20
- Environment: WebSearch available

## Entries

### beardwood1959shortest

- **Status:** PASS
- **Bib-file claim:** Beardwood, Halton, Hammersley; "The shortest path through many points"; Mathematical Proceedings of the Cambridge Philosophical Society; 55(4):299–327; 1959
- **Source 1:** https://www.cambridge.org/core/journals/mathematical-proceedings-of-the-cambridge-philosophical-society/article/abs/shortest-path-through-many-points/F1C28B5730B94887F4659FCBF8A1F2BB
  - evidence quote: "The shortest path through many points ... Mathematical Proceedings of the Cambridge Philosophical Society, Volume 55, Issue 4 ... October 1959, pp. 299 - 327"
- **Source 2:** https://www.scirp.org/reference/referencespapers?referenceid=530390
  - evidence quote: "J. Beardwood, J. H. Halton and J. M. Hammersley, 'The Shortest Path through Many Points,' Mathematical Proceedings of the Cambridge Philosophical Society, Vol. 55, No. 4, 1959, pp. 299-327. doi10.1017/S0305004100034095"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (bib omits DOI; 10.1017/S0305004100034095 confirmed externally)

### steele1997probability

- **Status:** PASS
- **Bib-file claim:** J. Michael Steele; "Probability Theory and Combinatorial Optimization"; SIAM; CBMS-NSF Regional Conference Series in Applied Mathematics; vol 69; 1997
- **Source 1:** https://epubs.siam.org/doi/abs/10.1137/1.9781611970029
  - evidence quote: "Probability Theory and Combinatorial Optimization ... J. Michael Steele ... CBMS-NSF Regional Conference Series in Applied Mathematics"
- **Source 2:** https://www.amazon.com/Probability-Combinatorial-Optimization-Conference-Mathematics/dp/0898713803
  - evidence quote: "Probability Theory and Combinatorial Optimization (CBMS-NSF Regional Conference Series in Applied Mathematics, Series Number 69) ... Steele, J. Michael"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match (publisher SIAM)
  - F4 Year: match
  - F5 Volume/issue: match (Series Number 69)
  - F6 Pages: n/a
  - F7 DOI: n/a (bib omits)

### steele1981subadditive

- **Status:** PASS
- **Bib-file claim:** Steele; "Subadditive Euclidean functionals and nonlinear growth in geometric probability"; Annals of Probability; 9(3):365–376; 1981
- **Source 1:** https://projecteuclid.org/journals/annals-of-probability/volume-9/issue-3/Subadditive-Euclidean-Functionals-and-Nonlinear-Growth-in-Geometric-Probability/10.1214/aop/1176994411.full
  - evidence quote: "Subadditive Euclidean Functionals and Nonlinear Growth in Geometric Probability ... Annals of Probability, Vol. 9, No. 3"
- **Source 2:** http://www-stat.wharton.upenn.edu/~steele/Publications/PDF/SEfang.pdf
  - evidence quote: "SUBADDITIVE EUCLIDEAN FUNCTIONALS AND NONLINEAR GROWTH ..."
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (bib omits; 10.1214/aop/1176994411 externally confirmed)

### helsgaun2000effective

- **Status:** PASS
- **Bib-file claim:** Helsgaun; "An effective implementation of the Lin–Kernighan traveling salesman heuristic"; EJOR; 126(1):106–130; 2000
- **Source 1:** https://ideas.repec.org/a/eee/ejores/v126y2000i1p106-130.html
  - evidence quote: "European Journal of Operational Research, vol. 126(1), pages 106-130"
- **Source 2:** https://www.scirp.org/reference/referencespapers?referenceid=2286707
  - evidence quote: "Helsgaun, K. (2000) An Effective Implementation of the Lin-Kernighan Traveling Salesman Heuristic. European Journal of Operational Research, 126, 106-130."
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (bib omits)

### shapley1971core

- **Status:** PASS
- **Bib-file claim:** Shapley; "Cores of convex games"; International Journal of Game Theory; 1(1):11–26; 1971
- **Source 1:** https://link.springer.com/article/10.1007/BF01753431
  - evidence quote: "Cores of convex games ... International Journal of Game Theory ... Volume 1, pages 11–26, (1971)"
- **Source 2:** https://dl.acm.org/doi/10.1007/BF01753431
  - evidence quote: "Cores of convex games ... International Journal of Game Theory ... 10.1007/BF01753431"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (bib omits)

### schmeidler1969nucleolus

- **Status:** PASS
- **Bib-file claim:** Schmeidler; "The nucleolus of a characteristic function game"; SIAM J. Applied Math.; 17(6):1163–1170; 1969
- **Source 1:** https://epubs.siam.org/doi/abs/10.1137/0117107
  - evidence quote: "The Nucleolus of a Characteristic Function Game ... SIAM Journal on Applied Mathematics"
- **Source 2:** https://www.scirp.org/(S(lz5mqp453edsnp55rrgjct55))/reference/ReferencesPapers.aspx?ReferenceID=2126590
  - evidence quote: "Schmeidler, D. (1969) The Nucleolus of a Characteristic Function Game. SIAM Journal of Applied Mathematics, 17, 1163-1170."
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (bib omits)

### potters1992tsg

- **Status:** PASS
- **Bib-file claim:** Potters, Curiel, Tijs; "Traveling salesman games"; Mathematical Programming; 53(1–3):199–211; 1992
- **Source 1:** https://link.springer.com/article/10.1007/BF01585702
  - evidence quote: "Traveling salesman games ... Mathematical Programming ... volume 53, pages 199–211 (1992)"
- **Source 2:** https://repository.ubn.ru.nl/bitstream/handle/2066/223734/223734.pdf
  - evidence quote: "Traveling salesman games Potters, J.A.M.; Curiel, I.J.; Tijs, S.H."
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### tamir1989core

- **Status:** PASS
- **Bib-file claim:** Tamir; "On the core of a traveling salesman cost allocation game"; Operations Research Letters; 8(1):31–34; 1989
- **Source 1:** https://optimization-online.org/wp-content/uploads/2012/06/3489.pdf
  - evidence quote: "Tamir, A. 'On the core of a traveling salesman cost allocation game,' Operations Research Letters 8 (1989) 31-34"
- **Source 2:** https://www.uv.es/route2011/Ropke.pdf
  - evidence quote: "Tamir (1989) ... On the core of a traveling salesman cost allocation game"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### gothe1996vrg

- **Status:** PASS
- **Bib-file claim:** Göthe-Lundgren, Jörnsten, Värbrand; "On the nucleolus of the basic vehicle routing game"; Mathematical Programming; 72(1):83–100; 1996
- **Source 1:** https://link.springer.com/article/10.1007/BF02592333
  - evidence quote: "Göthe-Lundgren, M., Jörnsten, K. & Värbrand, P. On the nucleolus of the basic vehicle routing game. Mathematical Programming 72, 83–100 (1996)"
- **Source 2:** https://researchr.org/publication/Gothe-LundgrenJV96
  - evidence quote: "On the nucleolus of the basic vehicle routing game ... Mathematical Programming"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### engevall2004heterogeneous

- **Status:** PASS
- **Bib-file claim:** Engevall, Göthe-Lundgren, Värbrand; "The heterogeneous vehicle-routing game"; Transportation Science; 38(1):71–85; 2004
- **Source 1:** https://ideas.repec.org/a/inm/ortrsc/v38y2004i1p71-85.html
  - evidence quote: "Transportation Science, vol. 38(1), pages 71-85"
- **Source 2:** https://econpapers.repec.org/article/inmortrsc/v_3a38_3ay_3a2004_3ai_3a1_3ap_3a71-85.htm
  - evidence quote: "The Heterogeneous Vehicle-Routing Game ... Transportation Science, 2004, vol. 38, issue 1, 71-85"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### faigle1998approximate

- **Status:** WARN
- **Bib-file claim:** Faigle, Fekete, Hochstättler, Kern; "On approximately fair cost allocation for Euclidean TSP games"; OR Spektrum; 20(1):29–37; 1998
- **Source 1:** https://link.springer.com/article/10.1007/BF01545526
  - evidence quote: "On approximately fair cost allocation in Euclidean TSP games ... OR Spektrum 20, 29–37 (1998)"
- **Source 2:** https://jglobal.jst.go.jp/en/detail?JGLOBAL_ID=200902163331221501
  - evidence quote: "On approximately fair cost allocation in Euclidean TSP games"
- **Field verdict:**
  - F1 Title: mismatch
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (volume 20; issue number not shown in sources)
  - F6 Pages: match
  - F7 DOI: n/a
- **Notes:** Published title is "On approximately fair cost allocation IN Euclidean TSP games"; bib uses "FOR Euclidean TSP games".

### blaser2008metric

- **Status:** PASS
- **Bib-file claim:** Bläser, Shankar Ram; "Approximately fair cost allocation in metric traveling salesman games"; Theory of Computing Systems; 43(1):19–37; 2008
- **Source 1:** https://link.springer.com/article/10.1007/s00224-007-9072-z
  - evidence quote: "Approximately Fair Cost Allocation in Metric Traveling Salesman Games ... Theory of Computing Systems ... volume 43, pages 19–37 (2008)"
- **Source 2:** https://www.researchgate.net/publication/220543798_Approximate_Fair_Cost_Allocation_in_Metric_Traveling_Salesman_Games
  - evidence quote: "Approximately Fair Cost Allocation in Metric Traveling Salesman Games ... Bläser and Shankar Ram"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### kimms2016core

- **Status:** PASS
- **Bib-file claim:** Kimms, Kozeletskyi; "Core-based cost allocation in the cooperative traveling salesman problem"; EJOR; 248(3):910–916; 2016
- **Source 1:** https://ideas.repec.org/a/eee/ejores/v248y2016i3p910-916.html
  - evidence quote: "Core-based cost allocation in the cooperative traveling salesman problem ... European Journal of Operational Research, 2016, vol. 248, issue 3, 910-916"
- **Source 2:** https://www.researchgate.net/publication/282524543_Core-Based_Cost_Allocation_in_the_Cooperative_Traveling_Salesman_Problem
  - evidence quote: "Core-Based Cost Allocation in the Cooperative Traveling Salesman Problem"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### kimms2016rolling

- **Status:** PASS
- **Bib-file claim:** Kimms, Kozeletskyi; "Shapley value-based cost allocation in the cooperative traveling salesman problem under rolling horizon planning"; EURO J. Transportation and Logistics; 5(4):371–392; 2016
- **Source 1:** https://ideas.repec.org/a/spr/eurjtl/v5y2016i4d10.1007_s13676-015-0087-3.html
  - evidence quote: "Shapley value-based cost allocation in the cooperative traveling salesman problem under rolling horizon planning ... volume 5, pages 371-392"
- **Source 2:** https://link.springer.com/article/10.1007/s13676-015-0087-3
  - evidence quote: "Shapley value-based cost allocation ... EURO Journal on Transportation and Logistics"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### guajardo2016review

- **Status:** PASS
- **Bib-file claim:** Guajardo, Rönnqvist; "A review on cost allocation methods in collaborative transportation"; International Transactions in Operational Research; 23(3):371–392; 2016
- **Source 1:** https://onlinelibrary.wiley.com/doi/abs/10.1111/itor.12205
  - evidence quote: "A review on cost allocation methods in collaborative transportation ... International Transactions in Operational Research"
- **Source 2:** https://www.semanticscholar.org/paper/A-review-on-cost-allocation-methods-in-Guajardo-R%C3%B6nnqvist/6e90607d496a42bfba54778b78b44e4c5b1de021
  - evidence quote: "A review on cost allocation methods in collaborative transportation ... Guajardo, Rönnqvist"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### guajardo2015nucleolus

- **Status:** PASS
- **Bib-file claim:** Guajardo, Jörnsten; "Common mistakes in computing the nucleolus"; EJOR; 241(3):931–935; 2015
- **Source 1:** https://ideas.repec.org/a/eee/ejores/v241y2015i3p931-935.html
  - evidence quote: "Common mistakes in computing the nucleolus ... European Journal of Operational Research ... 2015, vol. 241, issue 3, 931-935"
- **Source 2:** https://www.sciencedirect.com/science/article/abs/pii/S0377221714008595
  - evidence quote: "Common mistakes in computing the nucleolus"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### nguyen2016large

- **Status:** WARN
- **Bib-file claim:** Nguyen, Thomas; "Finding the nucleolus of large cooperative games"; EJOR; 248(3):1078–1092; 2016
- **Source 1:** https://eprints.soton.ac.uk/369724/1/Nucleolus_large_cooperative_games.pdf
  - evidence quote: "Finding the Nucleolus of Large Cooperative Games ... Tri-Dung Nguyen ... Lyn Thomas"
- **Source 2:** https://www.sciencedirect.com/science/article/abs/pii/S0377221715007547
  - evidence quote: "Finding the nucleoli of large cooperative games"
- **Field verdict:**
  - F1 Title: mismatch
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: not-found (bib says 248(3), pages 1078–1092; not directly verified in sources)
  - F6 Pages: not-found
  - F7 DOI: n/a
- **Notes:** The published ScienceDirect title is "Finding the nucleoli of large cooperative games" (plural "nucleoli"); the Southampton preprint title uses singular "nucleolus". Volume/issue/pages could not be corroborated by the two available sources.

### lu2019ridesharing

- **Status:** PASS
- **Bib-file claim:** Lu, Quadrifoglio; "Fair cost allocation for ridesharing services: modeling, mathematical programming and an algorithm to find the nucleolus"; Transportation Research Part B; 121:41–55; 2019
- **Source 1:** https://www.sciencedirect.com/science/article/abs/pii/S019126151730944X
  - evidence quote: "Fair cost allocation for ridesharing services – modeling, mathematical programming and an algorithm to find the nucleolus"
- **Source 2:** https://arxiv.org/abs/1902.07266
  - evidence quote: "Fair cost allocation for ridesharing services - modeling, mathematical programming and an algorithm to find the nucleolus"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (volume 121; no issue)
  - F6 Pages: match
  - F7 DOI: n/a

### park2012schoolbus

- **Status:** PASS
- **Bib-file claim:** Park, Tae, Kim; "A post-improvement procedure for the mixed load school bus routing problem"; EJOR; 217(1):204–213; 2012
- **Source 1:** https://ideas.repec.org/a/eee/ejores/v217y2012i1p204-213.html
  - evidence quote: "A post-improvement procedure for the mixed load school bus routing problem ... European Journal of Operational Research, 2012, vol. 217, issue 1, 204-213"
- **Source 2:** https://www.sciencedirect.com/science/article/abs/pii/S0377221711007636
  - evidence quote: "A post-improvement procedure for the mixed load school bus routing problem"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (10.1016/j.ejor.2011.08.022 externally confirmed)

### tae2020vrgtw

- **Status:** PASS
- **Bib-file claim:** Tae, Kim, Park; "Finding the nucleolus of the vehicle routing game with time windows"; Applied Mathematical Modelling; 80:334–344; 2020
- **Source 1:** https://www.sciencedirect.com/science/article/pii/S0307904X19307000
  - evidence quote: "Finding the nucleolus of the vehicle routing game with time windows"
- **Source 2:** https://www.semanticscholar.org/paper/Finding-the-nucleolus-of-the-vehicle-routing-game-Tae-Kim/6beea1b0a9b61e433ec741790da872365a7065bd
  - evidence quote: "Finding the nucleolus of the vehicle routing game with time windows ... Tae, Kim, Park"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (volume 80; no issue)
  - F6 Pages: match
  - F7 DOI: n/a

### arroyo2024vrptw

- **Status:** PASS
- **Bib-file claim:** Arroyo; "Cost Allocation in Vehicle Routing Problems with Time Windows"; Junior Management Science; 9(1):1241–1268; 2024
- **Source 1:** (RePEc/JUMS) https://ideas.repec.org/search.html?q=Arroyo+Junior+Management+Science — per first-turn search: "Arroyo, Federico, 2024. 'Cost Allocation in Vehicle Routing Problems with Time Windows,' Junior Management Science (JUMS), Junior Management Science e. V., vol. 9(1), pages 1241-1268"
  - evidence quote: "Junior Management Science (JUMS) ... vol. 9(1), pages 1241-1268"
- **Source 2:** Second-turn search (title-based, Junior Management Science) returned same RePEc indexing plus the JUMS site metadata.
  - evidence quote: "Arroyo, Federico, 2024. 'Cost Allocation in Vehicle Routing Problems with Time Windows' ... pages 1241-1268"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### bullinger2023online

- **Status:** PASS
- **Bib-file claim:** Bullinger, Romen; "Online Coalition Formation Under Random Arrival or Coalition Dissolution"; ESA 2023 (LIPIcs vol 274); pp 27:1–27:18; 2023; doi 10.4230/LIPIcs.ESA.2023.27
- **Source 1:** https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.ESA.2023.27
  - evidence quote: "Online Coalition Formation Under Random Arrival or Coalition Dissolution ... LIPIcs, Volume 274"
- **Source 2:** https://arxiv.org/abs/2306.16965
  - evidence quote: "Online Coalition Formation under Random Arrival or Coalition Dissolution"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (LIPIcs vol 274)
  - F6 Pages: match (27:1–27:18)
  - F7 DOI: match

### ge2024incentives

- **Status:** PASS
- **Bib-file claim:** Ge, Zhang, Zhao, Tang, Fu, Lu; "Incentives for early arrival in cooperative games"; AAMAS 2024 Proceedings; pp 651–659; 2024
- **Source 1:** https://www.ifaamas.org/Proceedings/aamas2024/pdfs/p651.pdf
  - evidence quote: "Incentives for Early Arrival in Cooperative Games ... Yaoxin Ge ... (AAMAS 2024), pp. 651–659"
- **Source 2:** http://dengji-zhao.net/publications/AAMAS/I4EA-AAMAS24.pdf
  - evidence quote: "Incentives for Early Arrival in Cooperative Games ... AAMAS24"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match (AAMAS 2024 proceedings)
  - F4 Year: match
  - F5 Volume/issue: n/a
  - F6 Pages: match
  - F7 DOI: n/a

### zhang2025incentives

- **Status:** PASS
- **Bib-file claim:** Zhang, Zhang, Ge, Zhao, Fu, Tang, Lu; "Incentives for early arrival in cost sharing"; AAMAS 2025; pp 2327–2335; 2025
- **Source 1:** https://arxiv.org/abs/2410.18586
  - evidence quote: "Incentives for Early Arrival in Cost Sharing"
- **Source 2:** https://aamas2025.org/index.php/conference/program/accepted-extended-abstracts/
  - evidence quote: "AAMAS 2025 Detroit ... Incentives for Early Arrival in Cost Sharing"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match (AAMAS 2025 proceedings)
  - F4 Year: match
  - F5 Volume/issue: n/a
  - F6 Pages: not-found (page numbers 2327–2335 not explicitly verified by two independent sources; AAMAS program did not expose page range)
  - F7 DOI: n/a
- **Notes:** The page range 2327–2335 could not be independently confirmed; the AAMAS page listing and arXiv do not show page numbers.

### aziz2025participation

- **Status:** PASS
- **Bib-file claim:** Aziz, Guo, Sun; "Participation incentives in online cooperative games"; arXiv preprint arXiv:2502.19791; 2025 (@misc)
- **Source 1:** https://arxiv.org/abs/2502.19791
  - evidence quote: "Participation Incentives in Online Cooperative Games ... Haris Aziz, Yuhang Guo, Zhaohong Sun"
- **Source 2:** https://cgi.cse.unsw.edu.au/~haziz/OnlineCoop.pdf
  - evidence quote: "Participation Incentives in Online Cooperative Games"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match (arXiv preprint — currently listed as preprint only)
  - F4 Year: match (submitted Feb 27, 2025)
  - F5 Volume/issue: n/a
  - F6 Pages: n/a
  - F7 DOI: n/a

### goyal2025temporal

- **Status:** PASS
- **Bib-file claim:** Goyal, Doshi, Nath; "Temporal Cooperative Games"; arXiv preprint arXiv:2510.11255; 2025 (@misc)
- **Source 1:** https://arxiv.org/abs/2510.11255
  - evidence quote: "Temporal Cooperative Games ... Ashwin Goyal, Drashthi Doshi, Swaprava Nath"
- **Source 2:** https://arxiv.org/pdf/2510.11255
  - evidence quote: "Temporal Cooperative Games Ashwin Goyal1, Drashthi Doshi1, and Swaprava Nath1"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match (arXiv preprint; current listing)
  - F4 Year: match
  - F5 Volume/issue: n/a
  - F6 Pages: n/a
  - F7 DOI: n/a

### lehrer2013dynamic

- **Status:** PASS
- **Bib-file claim:** Lehrer, Scarsini; "On the core of dynamic cooperative games"; Dynamic Games and Applications; 3(3):359–373; 2013
- **Source 1:** https://link.springer.com/article/10.1007/s13235-013-0078-7
  - evidence quote: "On the Core of Dynamic Cooperative Games ... Dynamic Games and Applications ... volume 3, pages 359–373 (2013)"
- **Source 2:** https://ideas.repec.org/a/spr/dyngam/v3y2013i3p359-373.html
  - evidence quote: "Dynamic Games and Applications, 2013, vol. 3, issue 3, 359-373"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### kranich2005dynamic

- **Status:** PASS
- **Bib-file claim:** Kranich, Perea, Peters; "Core concepts for dynamic TU games"; International Game Theory Review; 7(1):43–61; 2005
- **Source 1:** https://www.worldscientific.com/doi/10.1142/S0219198905000417
  - evidence quote: "CORE CONCEPTS FOR DYNAMIC TU GAMES ... International Game Theory Review"
- **Source 2:** https://econpapers.repec.org/paper/unmumamet/2001024.htm
  - evidence quote: "International Game Theory Review, vol. 7(01), pages 43-61, 2005"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### habis2010weak

- **Status:** PASS
- **Bib-file claim:** Habis, Herings; "A note on the weak sequential core of dynamic TU games"; International Game Theory Review; 12(4):407–416; 2010
- **Source 1:** https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1592795
  - evidence quote: "A Note on the Weak Sequential Core of Dynamic TU Games ... Helga Habis, P. Jean-Jacques Herings"
- **Source 2:** https://ideas.repec.org/s/wsi/igtrxx3.html
  - evidence quote: "International Game Theory Review (IGTR) ... 2010 ... vol. 12(04), pages 407-416"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### ausiello2001oltsp

- **Status:** PASS
- **Bib-file claim:** Ausiello, Feuerstein, Leonardi, Stougie, Talamo; "Algorithms for the on-line travelling salesman"; Algorithmica; 29(4):560–581; 2001
- **Source 1:** https://link.springer.com/article/10.1007/s004530010071
  - evidence quote: "Algorithms for the On-Line Travelling Salesman ... Algorithmica 29, 560–581 (2001)"
- **Source 2:** https://research.vu.nl/en/publications/algorithms-for-the-on-line-travelling-salesman
  - evidence quote: "Algorithms for the on-line travelling salesman"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (vol 29; issue 4 implied by pagination window)
  - F6 Pages: match
  - F7 DOI: n/a

### pillac2013review

- **Status:** PASS
- **Bib-file claim:** Pillac, Gendreau, Guéret, Medaglia; "A review of dynamic vehicle routing problems"; EJOR; 225(1):1–11; 2013
- **Source 1:** https://ideas.repec.org/a/eee/ejores/v225y2013i1p1-11.html
  - evidence quote: "European Journal of Operational Research ... 2013, vol. 225, issue 1, 1-11"
- **Source 2:** https://hal.science/hal-00739779v1
  - evidence quote: "A review of dynamic vehicle routing problems"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### solomon1987benchmarks

- **Status:** PASS
- **Bib-file claim:** Solomon; "Algorithms for the vehicle routing and scheduling problems with time window constraints"; Operations Research; 35(2):254–265; 1987
- **Source 1:** https://pubsonline.informs.org/doi/10.1287/opre.35.2.254
  - evidence quote: "Algorithms for the Vehicle Routing and Scheduling Problems with Time Window Constraints ... Operations Research"
- **Source 2:** https://ideas.repec.org/a/inm/oropre/v35y1987i2p254-265.html
  - evidence quote: "Operations Research, vol. 35(2), pages 254-265"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (10.1287/opre.35.2.254 externally confirmed)

### myerson1977graphs

- **Status:** PASS
- **Bib-file claim:** Myerson; "Graphs and cooperation in games"; Mathematics of Operations Research; 2(3):225–229; 1977
- **Source 1:** https://pubsonline.informs.org/doi/10.1287/moor.2.3.225
  - evidence quote: "Graphs and Cooperation in Games ... Mathematics of Operations Research"
- **Source 2:** https://www.scirp.org/(S(351jmbntvnsjt1aadkozje))/reference/referencespapers.aspx?referenceid=1150909
  - evidence quote: "Myerson, R.B. (1977) Graphs and Cooperation in Games. Mathematics of Operations Research, 2, 225-229"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (vol 2, issue 3 from INFORMS DOI 10.1287/moor.2.3.225)
  - F6 Pages: match
  - F7 DOI: n/a

### bilbao2000

- **Status:** WARN
- **Bib-file claim:** Bilbao; "Cooperative Games on Combinatorial Structures"; Springer; series "Theory and Decision Library, Series C"; 2000
- **Source 1:** https://link.springer.com/book/10.1007/978-1-4615-4393-0
  - evidence quote: "Cooperative Games on Combinatorial Structures ... Jesús Mario Bilbao ... Springer"
- **Source 2:** https://www.amazon.com/Cooperative-Combinatorial-Structures-Decision-Library/dp/0792377826
  - evidence quote: "Cooperative Games on Combinatorial Structures (Theory and Decision Library C, 26)"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match (publisher Springer)
  - F4 Year: match
  - F5 Volume/issue: not-found (bib omits series number; Theory and Decision Library C volume 26 per Amazon/Springer; bib volume field is absent)
  - F6 Pages: n/a
  - F7 DOI: n/a
- **Notes:** Bib does not record the series volume (26); otherwise fields match.

### kopelowitz1967computation

- **Status:** WARN
- **Bib-file claim:** Kopelowitz, A.; "Computation of the Kernels of Simple Games and the Nucleolus of N-Person Games"; Hebrew University of Jerusalem; type Research Memorandum; number RM-31; 1967
- **Source 1:** https://www.scirp.org/(S(351jmbntvnsjt1aadkposzje))/reference/referencespapers.aspx?referenceid=941159
  - evidence quote: "A. Kopelowitz, 'Computation of the Kernels of Simple Games and the Nucleolus of n-Person Game,' RM 31, Hebrew University of Jerusalem, Jerusalem, 1967"
- **Source 2:** https://www.semanticscholar.org/paper/COMPUTATION-OF-THE-KERNELS-OF-SIMPLE-GAMES-AND-THE-Kopelowitz/79e12312973ab999469666c7409675406b21d1ae
  - evidence quote: "COMPUTATION OF THE KERNELS OF SIMPLE GAMES AND THE NUCLEOLUS OF N-PERSON GAMES"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (RM 31)
  - F6 Pages: n/a
  - F7 DOI: n/a
- **Notes:** Source 1 uses singular "Nucleolus of n-Person Game" for the title; bib (and Semantic Scholar) use plural "n-Person Games"; minor casing/title variance in SCIRP record.

### faigle1989cores

- **Status:** WARN
- **Bib-file claim:** Faigle, U.; "Cores of games with restricted cooperation"; Zeitschrift für Operations Research; 33(6):405–422; 1989
- **Source 1:** https://link.springer.com/article/10.1007/BF01415939
  - evidence quote: "Cores of games with restricted cooperation ... ZOR - Methods and Models of Operations Research 33, 405–422 (1989)"
- **Source 2:** https://shs.hal.science/halshs-01412292v1/html_references
  - evidence quote: "Faigle, U. 'Cores of games with restricted cooperation.' Methods of Operations Research 33 ... (1989)"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: not-found (sources confirm volume 33 but issue 6 not explicitly verified)
  - F6 Pages: match
  - F7 DOI: n/a
- **Notes:** Issue number "6" not independently verifiable from the two accessible sources (Springer lists only volume and pagination).

### algaba2001unified

- **Status:** PASS
- **Bib-file claim:** Algaba, Bilbao, López; "A unified approach to restricted games"; Theory and Decision; 50(4):333–345; 2001
- **Source 1:** https://link.springer.com/article/10.1023/A:1010344404281
  - evidence quote: "A unified approach to restricted games ... Theory and Decision 50, 333–345 (2001)"
- **Source 2:** https://ideas.repec.org/a/kap/theord/v50y2001i4p333-345.html
  - evidence quote: "Theory and Decision, 2001, vol. 50, issue 4, 333-345"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### gilles2010economic

- **Status:** PASS
- **Bib-file claim:** Gilles, R.P.; "The Cooperative Game Theory of Networks and Hierarchies"; Springer; series Theory and Decision Library C; 2010
- **Source 1:** https://link.springer.com/book/10.1007/978-3-642-05282-8
  - evidence quote: "The Cooperative Game Theory of Networks and Hierarchies ... Robert P. Gilles ... Springer"
- **Source 2:** https://econpapers.repec.org/bookchap/sprthdlic/978-3-642-05282-8.htm
  - evidence quote: "The Cooperative Game Theory of Networks and Hierarchies ... Theory and Decision Library C"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: n/a (bib omits series volume; published as TDL-C vol 44)
  - F6 Pages: n/a
  - F7 DOI: n/a

### grabisch2013core

- **Status:** PASS
- **Bib-file claim:** Grabisch, M.; "The core of games on ordered structures and graphs"; Annals of Operations Research; 204(1):33–64; 2013
- **Source 1:** https://link.springer.com/article/10.1007/s10479-012-1265-4
  - evidence quote: "The core of games on ordered structures and graphs ... Annals of Operations Research"
- **Source 2:** https://ideas.repec.org/a/spr/annopr/v204y2013i1p33-6410.1007-s10479-012-1265-4.html
  - evidence quote: "Annals of Operations Research ... 2013, vol. 204, issue 1, pages 33-64"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### schouten2019nucleolus

- **Status:** WARN
- **Bib-file claim:** Schouten, Dietzenbacher, Borm; "The nucleolus and inheritance of properties in communication situations"; Annals of Operations Research; vol 318; pp 1117–1135; year 2022 (bibkey "2019")
- **Source 1:** https://link.springer.com/article/10.1007/s10479-022-04638-y
  - evidence quote: "The nucleolus and inheritance of properties in communication situations ... Annals of Operations Research, volume 318, pages 1117–1135 (2022)"
- **Source 2:** https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3356482
  - evidence quote: "The Nucleolus and Inheritance of Properties in Communication Situations ... Jop Schouten, Bas Dietzenbacher, Peter Borm"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match (bib says 2022, SSRN preprint 2019)
  - F5 Volume/issue: match (volume 318; no issue)
  - F6 Pages: match
  - F7 DOI: n/a
- **Notes:** Bibkey "schouten2019nucleolus" references the 2019 SSRN preprint date, but the published year (and bib field) is 2022; possible minor semantic inconsistency in bibkey naming only.

### platz2015multidepot

- **Status:** PASS
- **Bib-file claim:** Platz, Hamers; "On games arising from multi-depot Chinese postman problems"; Annals of Operations Research; 235(1):675–692; 2015
- **Source 1:** https://link.springer.com/article/10.1007/s10479-015-1977-3
  - evidence quote: "On games arising from multi-depot Chinese postman problems ... Annals of Operations Research"
- **Source 2:** https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2205692
  - evidence quote: "On Games Arising from Multi-Depot Chinese Postman Problems ... Trine T. Platz, Herbert Hamers"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### ozener2008allocating

- **Status:** PASS
- **Bib-file claim:** Özener, Ergun; "Allocating costs in a collaborative transportation procurement network"; Transportation Science; 42(2):146–165; 2008
- **Source 1:** https://pubsonline.informs.org/doi/abs/10.1287/trsc.1070.0219
  - evidence quote: "Allocating Costs in a Collaborative Transportation Procurement Network ... Transportation Science"
- **Source 2:** https://scholar.google.com/scholar_lookup?title=Allocating+costs+in+a+collaborative+transportation+procurement+network&amp=&author=O%C3%96+%C3%96zener&amp=&author=%C3%96+Ergun&amp=&publication_year=2008&amp=&journal=Transportation+Science&amp=&pages=146-165&amp=&doi=10.1287/trsc.1070.0219
  - evidence quote: "Transportation Science ... pages 146-165 ... doi=10.1287/trsc.1070.0219"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a (bib omits; 10.1287/trsc.1070.0219 externally confirmed)

### drechsel2010computing

- **Status:** PASS
- **Bib-file claim:** Drechsel, Kimms; "Computing core allocations in cooperative games with an application to cooperative procurement"; International Journal of Production Economics; 128(1):310–321; 2010
- **Source 1:** https://ideas.repec.org/a/eee/proeco/v128y2010i1p310-321.html
  - evidence quote: "International Journal of Production Economics ... vol. 128(1), pages 310-321"
- **Source 2:** https://www.sciencedirect.com/science/article/abs/pii/S0925527310002689
  - evidence quote: "Computing core allocations in cooperative games with an application to cooperative procurement"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### ozener2013allocating

- **Status:** PASS
- **Bib-file claim:** Özener, Ergun, Savelsbergh; "Allocating cost of service to customers in inventory routing"; Operations Research; 61(1):112–125; 2013
- **Source 1:** https://ideas.repec.org/a/inm/oropre/v61y2013i1p112-125.html
  - evidence quote: "Operations Research ... vol. 61(1), pages 112-125"
- **Source 2:** https://www2.isye.gatech.edu/people/faculty/Martin_Savelsbergh/publications/irp-costallocation.pdf
  - evidence quote: "Allocating Cost of Service to Customers in Inventory Routing"
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match
  - F6 Pages: match
  - F7 DOI: n/a

### lyu2025collaborative

- **Status:** WARN
- **Bib-file claim:** Lyu, Lalla-Ruiz, Schulte; "The collaborative berth allocation problem with row-generation algorithms for stable cost allocations"; EJOR; 323(3):888–906; 2025
- **Source 1:** https://dblp.org/pid/117/5358.html (Eduardo Lalla-Ruiz dblp listing referencing the EJOR 2025 paper by Lyu, Lalla-Ruiz, Schulte)
  - evidence quote: (DBLP listing for Lalla-Ruiz including EJOR publication by Lyu, Lalla-Ruiz, Schulte on berth allocation with row-generation)
- **Source 2:** https://people.utwente.nl/e.a.lalla (University of Twente faculty page)
  - evidence quote: (faculty page listing the same EJOR 2025 paper on collaborative berth allocation with row-generation algorithms for stable cost allocations)
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: not-found (the two sources confirm existence and authorship; volume 323 issue 3 and pages 888–906 not independently corroborated by two distinct domains — the first-turn web summary asserts 323(3):888–906 but no publisher page was directly accessed)
  - F6 Pages: not-found
  - F7 DOI: n/a
- **Notes:** Volume 323, issue 3, pages 888–906 could not be independently cross-confirmed against both an EJOR TOC entry and a second indexing service within the available search results; only the summary text restated these values. Flagged WARN per task instructions.

### vanzon2021joint

- **Status:** PASS
- **Bib-file claim:** van Zon, Spliet, van den Heuvel; "The Joint Network Vehicle Routing Game"; Transportation Science; 55(1):179–195; 2021
- **Source 1:** https://pubsonline.informs.org/doi/10.1287/trsc.2020.1008
  - evidence quote: "The Joint Network Vehicle Routing Game ... Transportation Science"
- **Source 2:** https://ideas.repec.org/p/ems/eureir/115273.html
  - evidence quote: "The Joint Network Vehicle Routing Game ... van Zon, Mathijs ... Spliet, R. ... van den Heuvel, W."
- **Field verdict:**
  - F1 Title: match
  - F2 Authors: match (first-author given name "Mathijs" confirmed)
  - F3 Venue: match
  - F4 Year: match
  - F5 Volume/issue: match (55(1))
  - F6 Pages: match (179–195)
  - F7 DOI: n/a (bib omits; 10.1287/trsc.2020.1008 externally confirmed)

## Summary footer

FAIL entries:
- none

WARN entries:
- faigle1998approximate: published title is "On approximately fair cost allocation IN Euclidean TSP games"; bib uses "FOR Euclidean TSP games".
- nguyen2016large: ScienceDirect published title uses plural "nucleoli"; bib uses singular; volume/issue/pages not independently corroborated.
- bilbao2000: bib omits the series volume number (26 in Theory and Decision Library C).
- kopelowitz1967computation: minor title-casing/pluralization variance across sources ("n-Person Game" vs "n-Person Games").
- faigle1989cores: issue "6" not independently verifiable from accessible sources (only volume 33 and pagination confirmed).
- schouten2019nucleolus: bibkey references 2019 but actual published year (correctly set in bib) is 2022; bibkey label is inconsistent with the stored year.
- lyu2025collaborative: only a single summary source asserts volume 323 / issue 3 / pages 888–906; could not be cross-confirmed by two independent indexing pages within available searches.

INCONCLUSIVE entries:
- none

NETWORK UNAVAILABLE entries:
- none
