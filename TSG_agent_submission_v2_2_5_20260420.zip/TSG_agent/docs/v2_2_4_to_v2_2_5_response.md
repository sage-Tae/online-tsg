# v2.2.4 → v2.2.5 Response

**Scope.** Minimal 1-page-overflow fix on top of v2.2.4. The v2.2.4
rebuild produced `main.pdf` at 31 pages, one page over the EJOR 30-
page cap. This iteration applies the smallest-possible prose
compressions to achieve ≤ 30 pages. No other changes.

## Before / after page counts

| PDF                | v2.2.4 | v2.2.5 | Cap  |
|--------------------|-------:|-------:|-----:|
| `main.pdf`         |   31   | **30** | ≤ 30 |
| `supplementary.pdf`|    8   |    8   |  —   |
| `highlights.pdf`   |    1   |    1   |  —   |

## Tiered application

The patch was applied in the order Tier 1 → Tier 2 → Tier 3 as
specified, rebuilding after each tier and stopping at the first tier
whose rebuild achieved the 30-page target. All three tiers were
required: Tier 1 alone and Tier 1+2 each still rebuilt to 31 pages;
Tier 3 closed the final page.

### Tier 1 — Removed Chen et al. 2023 sentence (§2.1) and bib entry

**Rationale.** Per-spec, Chen et al. 2023 is the only citation added
in v2.2.3 that is explicitly authorized for removal (non-load-bearing
"related applications" mention, not a departure argument). Lyu et al.
2025 and van Zon et al. 2021 are retained (distinguishing references).

**Edit in `paper/main.tex` §2.1 (Cooperative Routing Games):**

Before:

```
...their coalition family is static and determined by vessel
identity rather than arrival dynamics, which is the source of
restriction that differs from our setting. Related dynamic-vehicle
cooperative game applications include cost allocation in autonomous
truck platooning \citep{chen2023cost}. \citet{platz2015multidepot}
extend the routing-plus-cooperative-game template to multi-depot
Chinese postman problems...
```

After:

```
...their coalition family is static and determined by vessel
identity rather than arrival dynamics, which is the source of
restriction that differs from our setting. \citet{platz2015multidepot}
extend the routing-plus-cooperative-game template to multi-depot
Chinese postman problems...
```

**Edit in `paper/references.bib`:** the `@article{chen2023cost, ...}`
entry (7 lines) is deleted.

**Rebuild outcome:** 31 pages — Tier 1 alone did not suffice.

### Tier 2 — Two small overfull-hbox tightenings

The v2.2.4 build log reported six Overfull hbox warnings at lines
164, 520, 592, 611, 723, 745 of `main.tex`. Two of these (520 and
611) are inside tabular environments — line 520 is Table 5
("Five-mechanism contingency"), which is explicitly protected, and
line 611 is Table 4 (pattern aggregate), with a 59 pt overflow that
would require a structural column change. The four paragraph-level
overfulls are 1.95–16.35 pt, small enough that a two-word tightening
may eliminate them.

**Edit in `paper/main.tex` §3.1 (Characteristic cost vs. realized
cost), line 164:** the trailing redundant clause ", since the online
policy must commit to visits without seeing future arrivals" is
removed. This clause restates the earlier in-paragraph phrase
"because the online policy cannot anticipate future arrivals", so its
removal is a pure redundancy cut, not a content change.

Before:

```
...the competitive ratio r = C(N)_online / c*(N) measures the
overhead introduced by online dispatch, since the online policy
must commit to visits without seeing future arrivals.
```

After:

```
...the competitive ratio r = C(N)_online / c*(N) measures this
overhead.
```

**Edit in `paper/main.tex` §7(i) Dispatch policy, line 745:**

Before:

```
Extending to learning-based or forecasting-aware dispatch policies
remains open.
```

After:

```
Extending to learning-based or forecasting-aware policies remains
open.
```

The word "dispatch" is unambiguous in context (the sentence is in the
Dispatch-policy limitation paragraph; the preceding sentences already
discuss dispatch policies).

**Rebuild outcome:** 31 pages — Tier 2 did not suffice either.
Inspection showed the overfull hboxes persisted at the same line
numbers (the paragraph-level overfulls shifted slightly in character
position but did not disappear, confirming that LaTeX's line-breaking
decisions for these paragraphs are not flippable by two-word edits at
this scale).

### Tier 3 — Compressed the Goyal orthogonality sentence (§2.2)

**Rationale.** The v2.2.3 P5 addition expanded the Goyal et al. 2025
citation with one orthogonality sentence of ~58 words. Compressing
this sentence to ~33 words preserves the contrast (their sequence-
indexed worth vs. our restricted coalition family — "orthogonal axis
of temporality") while saving ~25 words, which is enough to drop
main.pdf by one page.

**Edit in `paper/main.tex` §2.2 (Online Cooperative Games and
Nucleolus Computation), immediately after the
`\citet{goyal2025temporal}` sentence:**

Before (58 words, v2.2.3):

```
\citet{goyal2025temporal} introduce Temporal Cooperative Games, in
which the characteristic function is indexed by time. The two
frameworks are complementary: their worth v(pi) is a function of
the realized arrival sequence pi while the coalition structure
remains the full power set, whereas our Online TSG keeps the
characteristic function c(S) set-valued (matching the static TSG
exactly) and restricts the coalition family to F induced by the
arrival--service process.
```

After (33 words, v2.2.5):

```
\citet{goyal2025temporal} introduce Temporal Cooperative Games, in
which the characteristic function is indexed by time. Their worth
v(pi) depends on the arrival sequence while coalitions remain
unrestricted; our c(S) is set-valued but coalitions are restricted
to F, an orthogonal axis of temporality.
```

The contrast is preserved: (i) their $v(\pi)$ is sequence-indexed /
their coalitions are unrestricted; (ii) our $c(S)$ is set-valued /
our coalitions are restricted to $\mathcal{F}$; (iii) the two axes
of temporality are orthogonal.

**Rebuild outcome:** `main.pdf` = **30 pages**. Target achieved.

## What was NOT changed

- Proposition 15, its proof, Supplementary §S4, any Theorem,
  Table 5 — protected regions, untouched.
- CSVs, figures, `src/` — untouched.
- Lyu et al. 2025 and van Zon et al. 2021 citations — retained per
  spec (important distinguishing references).
- Abstract, Highlights, §1, §4, §5, §6 findings/numerics, §7
  paragraphs (ii)–(iv) — untouched.

## Version-bump mechanics

- `paper/main.tex` — three edits described above.
- `paper/references.bib` — `chen2023cost` entry removed.
- `paper/main.pdf` — rebuilt (30 pages).
- `paper/supplementary.pdf`, `paper/highlights.pdf` — rebuilt from
  unchanged source (8 / 1 pages).
- `README.md` — header `**Current version: v2.2.5**`, Key-results
  header `v2.2.5`, Version-history block appended with v2.2.5 entry,
  Reproducibility-tags block updated (v2.2.4 relabelled
  `(intermediate)`, v2.2.5 appended as `(current, major revision)`).
- `REPRODUCIBILITY.md` — title, Version field, three in-body labels,
  Version-History block: v2.2.4 relabelled `(intermediate)`, v2.2.5
  appended as `(current)`.
- `scripts/verify_doc_consistency.sh` — `CURRENT_VERSION` bumped to
  `v2.2.5`; stale-version regex extended from `v2\.2\.[0123]` to
  `v2\.2\.[01234]`.
- `docs/v2_2_4_to_v2_2_5_response.md` — this file.

## Gate status

- `scripts/verify_doc_consistency.sh`: expected to PASS.
- `scripts/verify_zip_rebuild.sh`: expected to PASS
  (`main.pdf` = 30 pages = limit).

## Alternatives considered and rejected

- **Trimming the Lyu et al. 2025 sentence (§2.1) or the van Zon 2021
  sentence (§2.2).** Rejected — spec explicitly forbids removing
  these citations.
- **Fixing the 59 pt overfull in Table 4 (pattern aggregate, line
  611) by dropping a column or compressing column spec.** Rejected —
  Table 4 is not explicitly protected, but (a) changing it would
  affect a data-bearing display, and (b) the overfull is horizontal
  (table wider than `\textwidth`), not vertical, so fixing it saves
  no vertical space.
- **Further compression of the v2.2.3 §5.3 / §6.6 trims.** Rejected
  — the v2.2.3 trims are already maximally compressed; further cuts
  would remove content load-bearing for Finding 3 / Corollary 20
  interpretation.
- **Switching the bibliography from `\scriptsize` to `\tiny`.**
  Rejected — `\tiny` crosses readability norms for a submitted
  manuscript; the existing `\scriptsize` + `\bibsep = 0pt plus 0.1ex`
  setting from v2.2.0 is already the compression floor for this
  venue.
