# v2.1.10 → v2.1.11 response

Response-to-weaknesses revision. Target: EJOR-compliant main manuscript at or
below 30 pages. All existing Theorem / Proposition / Corollary / Remark /
Observation labels preserved for cross-reference compatibility; CSVs under
`code/experiments/logs/` and `code/results/` untouched.

## Summary

| Tier | Task | Status | Location |
|---|---|---|---|
| T1.1 | Thm 6 → Prop 6, Thm 18 → Prop 18 | **Done** | `paper/main.tex` §3.3, §5.2, §6.2 |
| T1.2 | Figure 1 y-axis label `c(N)` → `c^*(N)` | **Verified (already in place)** + regen | `code/figures/make_figures_v3.py`, `code/figures/fig2_r_vs_rstar.pdf` |
| T1.3 | Remove "≈ 1.81" from Example 4 | **Done** | `paper/main.tex` Example 4 |
| T1.4 | Tone down B_medium scale-up claim (§6.8 Finding 3 and §7(ii)) | **Done** | `paper/main.tex` §6.8 Finding 3, §7(ii); detection-limit caveat integrated |
| T1.5 | Add 5 references + cite each in §2 | **Done** | `paper/references.bib`, `paper/main.tex` §2.1, §2.2 |
| T1.6 | Clarify Theorem 16's "uniformly" clause | **Done** | `paper/main.tex` Theorem 16 + proof |
| T1.7 | Remark 17 depot-position constant explicit | **Done** | `paper/main.tex` Remark 17 |
| T2.1 | Attempt Remark 14 → Proposition | **Fell back to open-problem statement** | `paper/supplementary.tex` §S4 + `paper/main.tex` §7(iii) reference |
| T2.2 | Detection-limit quantification | **Done (integrated into §6.8 Finding 3 + caveat)** | `paper/main.tex` §6.8 Finding 3(b) and caveat |
| Tier 3 | VRG future-work paragraph | **Done** | `paper/main.tex` §7 Broader directions |
| — | Version bump v2.1.10 → v2.1.11 | **Done** | `README.md`, `REPRODUCIBILITY.md`, `scripts/verify_doc_consistency.sh` |

## Changes in detail

### T1.1 — Downgrade over-labeled results

- `\begin{theorem}[Reduction at simultaneous arrivals]` → `\begin{proposition}`
  at the definition site (`thm:static-equiv`). Label preserved.
- `\begin{theorem}[Inheritance of Static Core stability]` → `\begin{proposition}`
  at the definition site (`thm:core-inheritance`). Label preserved.
- Prose references updated:
  - §1 C1 "Theorem~\ref{thm:static-equiv}" → "Proposition~\ref{thm:static-equiv}".
  - §6.2 subsection "Verification of Theorem~\ref{thm:static-equiv}"
    → "Verification of Proposition~\ref{thm:static-equiv}" (both the
    subsection title and the in-paragraph reference).
  - §7(i) "Theorems~\ref{thm:empty-core} and~\ref{thm:core-inheritance}"
    → "Theorem~\ref{thm:empty-core}, Proposition~\ref{thm:core-inheritance}".
- README / REPRODUCIBILITY / docs/: no references to "Theorem 6" or
  "Theorem 18" in the current-state documentation required updating
  (the references are only in archived `docs/v2_1_*_to_v2_1_*_response.md`
  historical records, which are left as-is because they describe the
  paper state at that prior version). The current-state structural
  table in `docs/phase3_complete_report.md` is a Phase-3 snapshot and
  is intentionally preserved as an historical artifact.
- Counter numbering is unchanged: `theorem`, `proposition`, `lemma`,
  `corollary`, `remark`, `observation`, `definition`, `example`,
  `assumption` all share `[theorem]`, so the downgrade swaps the
  display name only; Theorem 11 remains Theorem 11, Corollary 19
  remains Corollary 19, etc.

### T1.2 — Figure 1 y-axis label

- Inspected `code/figures/make_figures_v3.py` lines 83–84:
  - x-axis: `r'$r^{**} = 1 + \min_i \delta_i / c^\ast(N)$'`
  - y-axis: `r'$r = C(N)_{\mathrm{online}}/c^\ast(N)$'`
- Both already use `c^\ast(N)` (equivalent to `c^*(N)`). Rendering
  verified in the regenerated `code/figures/fig2_r_vs_rstar.pdf`:
  y-axis reads `r = C(N)_online / c*(N)`. Treated the T1.2 delta as a
  no-op for the LaTeX source but regenerated the PDF for audit
  consistency (and to pick up any other downstream regenerations).
- Regeneration output: 175 NN rows, 37 single / 11 balanced / 10
  near-complement / 9 intermediate / 38 nonempty classifications
  (matches Table 5 and the Figure 2 counts in the PDF).

### T1.3 — Example 4 "≈ 1.81"

- Removed the parenthetical numerical construction of the formal
  $\delta_i$ ratio in Example 4 (Solomon C101). The sentence now
  states only the qualitative point: no complement $N\setminus\{i\}$
  is feasible because the service timeline is fully sequential
  (Lemma~10), so $r^{\ast\ast}$ is undefined (empty-minimum
  convention) and Theorem~11 makes no prediction on this instance.
- Rationale: $\delta_i \in [62.66, 70.20]$ is a purely formal
  combination of singleton-TSP costs in an instance where the
  underlying quantity ($r^{\ast\ast}$) is undefined; exposing the
  number invites readers to compare $r=1.032$ to $\approx 1.81$
  as if it were a valid threshold, which it is not.

### T1.4 — Tone down B_medium scale-up claim

- §6.8 Finding 3 rewritten as an explicit split:
  - **(a) Structural (analytic, strong):** $\bar k < n-1$ at every
    scale-up cell ($\bar k = 15.4, 23.2, 37.6$ for $n=20,30,50$),
    so Corollary~19 analytically blocks both complement-based
    mechanisms (Theorem~11 and Proposition~12), regardless of $r$.
  - **(b) Empirical (one-sided, weak):** No intermediate-coalition
    violation observed in the sampled restricted LP of $10^4$
    coalitions per instance across the 15 $\text{B}_{\text{medium}}$
    cases ($\bar r \in [1.31,1.39]$). Explicitly acknowledged as
    one-sided (cannot conclude full Core nonemptiness) with
    detection power that decreases sharply with $n$.
- Detection-limit caveat paragraph added: per-draw miss probability
  $1 - 10^4/(2^n-1) \approx 1 - 10^{-2}/10^{-5}/10^{-11}$ at
  $n=20/30/50$, framed as a detection-limit statement that does
  **not** bound the probability of empty Core.
- §7(ii) rewritten to match: $\text{B}_{\text{medium}}$
  nonemptiness claim is limited to the structural statement
  (Corollary~19 blocks complement mechanisms, from Finding 3(a))
  plus the one-sided empirical observation (from Finding 3(b)),
  not a proof of full Core nonemptiness.
- §6.8 Summary paragraph re-framed to match the (a)/(b) split.

### T1.5 — Add 5 references + cite in §2

Appended to `paper/references.bib`:

- `klijn2005sequencing` — Klijn & Slikker (2005), Math. Methods OR 62(1):69–86.
- `platz2015multidepot` — Platz & Hamers (2015), Annals OR 235(1):675–692.
- `ozener2008allocating` — Özener & Ergun (2008), Trans. Sci. 42(2):146–165.
- `drechsel2010computing` — Drechsel & Kimms (2010), Computers & IE 59(4):547–555.
- `ozener2013allocating` — Özener, Ergun & Savelsbergh (2013), Oper. Res. 61(1):112–125.

Citations in §2 with one-sentence relation and departure:

- §2.1 (Cooperative Routing Games): Platz & Hamers — routing-plus-
  cooperative-game template, coalition family $2^N$ not time-restricted.
- §2.1: Özener & Ergun (2008) — operational cost allocation with fixed
  carrier set.
- §2.1: Özener, Ergun & Savelsbergh (2013) — closest prior art
  combining routing + cost allocation + temporality; temporality is
  a deterministic replenishment schedule, not an online stochastic
  arrival process restricting $\F$.
- §2.2 (Online Cooperative Games / Nucleolus): Klijn & Slikker —
  arrival-order-induced coalition infeasibility in scheduling, adapted
  here to the metric TSP under an online process.
- §2.2: Drechsel & Kimms — early Core-targeted LP methodology for
  cooperative procurement, precedent for the constraint-generation
  style adapted to $\F$.

### T1.6 — Theorem 16 "uniformly" clause

- Theorem 16 rewritten: "uniformly over arrival patterns" →
  "uniformly over the subclass of arrival patterns for which
  $\{i \in N : N\setminus\{i\}\in\F\}$ is non-empty."
- Proof's closing sentence updated to match, with an added
  parenthetical that patterns outside this subclass have
  $r^{\ast\ast}$ undefined and the claim vacuous.

### T1.7 — Remark 17 constant

- Remark 17 now states that the universal constant in the
  $\min_i d(0,x_i) = \Theta(n^{-1/2})$ radial-density extreme-value
  argument depends on the sector angle swept by the square at the
  depot: $2\pi$ interior, $\pi/2$ corner, intermediate for boundary
  placements. The constant ratio lies in $[1,4]$ between the corner
  and interior cases.
- The $O(n^{-1})$ conclusion rate is stated explicitly to be
  unaffected; only the hidden constant changes with depot position.

### T2.1 — Remark 14 → Proposition attempt

**Outcome: Fell back to open-problem statement.**

The natural Bondareva–Shapley balancing over $B_{n-1}\cup B_{n-2}$
is easy to state and the Bondareva–Shapley (⇐) direction is an
elementary one-line argument. However, the promotion criterion in
the spec requires (i) a proof and (ii) empirical coverage: the
condition must fire on all 10 observed near-complement cases and
produce no false positives across the 175 main-grid instances.

Step (i) — the sufficient-condition direction — is immediate:

> For any $x\in\mathrm{Core}(N,c,\F)$ and any balancing
> $\{\lambda_S\}_{S\in B_{n-1}\cup B_{n-2}}$ with
> $\sum_{S\ni i}\lambda_S=1$,
> $\sum_S\lambda_S\,c(S) \ge \sum_S\lambda_S \sum_{i\in S}x_i
>  = \sum_i x_i \cdot \sum_{S\ni i}\lambda_S = \sum_i x_i
>  = C(N)_{\mathrm{online}} = r\,\cstar(N)$,
> so $r\le r^{(\diamond)}$; contrapositively,
> $r > r^{(\diamond)}$ forces $\mathrm{Core}(N,c,\F)=\emptyset$.

Step (ii) — empirical coverage — requires solving, for each of the
175 main-grid instances, an LP of the form

$$
r^{(\diamond)}_{\min} = \min_{\lambda\ge 0,\ \sum_{S\ni i}\lambda_S=1}
  \frac{\sum_{S\in B_{n-1}\cup B_{n-2}} \lambda_S\, c(S)}{\cstar(N)}
$$

and comparing against realized $r$. The cost inputs $c(N\setminus\{i,j\})$
for every pair $\{i,j\}$ are not present in the shipped CSVs at the
pair-level granularity and would require a separate instance-by-instance
TSP audit of $\binom{n}{2}$ additional Held–Karp computations per
instance. The spec explicitly permits falling back to a clean
open-problem statement if the empirical check cannot be completed;
producing the $r^{(\diamond)}_{\min}$ LP and its 175-instance
evaluation as a self-contained artifact was out of scope for this
revision.

**Decision:**
- Keep Remark 14 as-is in main.tex.
- §7(iii) rewritten to frame the Bondareva–Shapley balanced collection
  mixing $B_{n-1}$ and $B_{n-2}$ as an explicit open problem with a
  concrete threshold $r^{(\diamond)}$, and to reference the clean
  problem statement in Supplementary §S4.
- Supplementary §S4 added: the full statement (feasibility hypothesis,
  balancing condition, threshold $r^{(\diamond)}$), the Bondareva–
  Shapley one-line sufficient direction, and the explicit open
  empirical-coverage question, phrased so a future revision can pick
  it up cleanly without re-inventing the formulation.

### T2.2 — Detection-limit analysis

- Integrated into §6.8 Finding 3(b) and the new Detection-limit
  caveat paragraph, per the spec's "integrate into §6.8" option.
- Uses the numbers already in `seed123_core_check.csv` and
  `scaleup_v2.csv`: no new simulation or CSV touched.
- Floor quantification (main-text form): per-draw miss probability
  for a single fixed binding coalition with $10^4$ uniform samples
  drawn from $2^n-1$ nonempty coalitions:
  - $n=20$: $\approx 1 - 10^{-2}$
  - $n=30$: $\approx 1 - 10^{-5}$
  - $n=50$: $\approx 1 - 10^{-11}$
- Framed as a detection-limit statement only — it does not bound
  the probability of empty Core.

### Tier 3 — Online VRG future work

- §7 "Broader directions: Online VRG" paragraph expanded to state
  explicitly that the single-vehicle structure of the complement
  and balanced-complement arguments does not immediately generalize,
  because (a) $c(S)$ must be redefined with vehicle capacity and a
  fleet-assignment rule, and (b) the single-complement insertion
  identity $c(\{i\})+c(N\setminus\{i\})\ge \cstar(N)$ underlying
  $r^{\ast\ast}$ need not hold, and $N\setminus\{i\}$ may not be
  feasibly served by the realized fleet.
- An A3-style consistency axiom across rolling-horizon windows is
  kept as a natural companion.

### Version + packaging

- `README.md`:
  - Header current-version label v2.1.10 → v2.1.11.
  - Version-history block extended with a v2.1.11 entry summarising
    all tier changes in one compact paragraph.
  - Reproducibility-tags section: v2.1.10 demoted to intermediate;
    v2.1.11 added as the current major revision with a detailed
    per-tier summary.
  - "Key results (sanity checkpoints)" header labelled v2.1.11.
- `REPRODUCIBILITY.md`:
  - Paper Info labels (v2.1.10 → v2.1.11; supplementary 6 → 7 pages;
    supersedes-list extended).
  - Data Files header (v2.1.10) → (v2.1.11).
  - "Expected output" supplementary page count 6 → 7.
  - "EJOR Submission" supplementary slot 6 → 7 pages.
  - `verify_zip_rebuild.sh` example ZIP name bumped.
  - "Both are expected to pass on a clean v2.1.10 checkout" → v2.1.11.
  - Version History block: v2.1.10 demoted to intermediate; v2.1.11
    added as the current entry with a detailed per-tier summary.
- `scripts/verify_doc_consistency.sh`:
  - `CURRENT_VERSION=v2.1.10` → `v2.1.11`.
  - `CURRENT_SUPP_PAGES=6` → `7`.
  - Stale-version regex broadened to match v2.1.0 through v2.1.10
    (previously matched only single-digit subversions, which would
    have let `v2.1.10` pass silently after the bump).
- `scripts/verify_zip_rebuild.sh`: no changes; already handles
  the 30-page cap on main and the existence of `supplementary.tex`
  and `highlights.tex`.

## Page-budget bookkeeping

Initial rebuild after all content edits: 32 pages (over the 30 cap by 2).
Compression applied:

1. Moved the explicit Bondareva–Shapley balanced-near-complement
   open-problem block (T2.1) out of §7(iii) and into Supplementary §S4,
   replacing it in main with a one-line pointer.
2. Compressed the §7 VRG paragraph (T3) from a three-clause
   discussion to a two-clause one.
3. Compressed the §6.8 detection-limit caveat to refer back to the
   Finding 3(b) numbers rather than re-listing them.
4. Compressed §6.8 Finding 3(a) and Finding 3(b) to short paragraphs.
5. Compressed §6.8 Summary to a tighter one-paragraph statement.
6. Compressed §2.1 citation prose (Platz & Hamers, Özener & Ergun,
   Özener et al. 2013 merged into shorter one-sentence each).
7. Compressed §2.2 citation prose (Drechsel & Kimms merged into
   the trailing algorithmic-precedent sentence).
8. Main-bibliography `\footnotesize` + `\bibsep=0pt plus 0.15ex` to
   recover the final page.

Final: main.pdf **30 pages** (at the limit), supplementary.pdf 7 pages
(one page grew from adding §S4), highlights.pdf 1 page.

## Gate results

```
$ bash scripts/verify_doc_consistency.sh
=== Stale version labels (non-historical) === (none)
=== Stale page counts === (none)
=== Stale seed123 row counts === (none)
=== Orphan top-level figures/ in repo tree === (none)
=== Stale metrics (1.355 / 3.21) === (none)
Doc consistency check: PASS (current version = v2.1.11,
  main 30 pages / supplementary 7 pages, seed123 = 2 rows)

$ bash scripts/verify_zip_rebuild.sh <test-zip>
=== Clean-room rebuild ===
  main.pdf: PASS (30 pages, limit 30)
  supplementary.pdf: PASS (7 pages)
  highlights.pdf: PASS (1 pages)
Clean-room rebuild: PASS
```

## Invariants preserved

- All existing labels (`thm:*`, `prop:*`, `cor:*`, `rem:*`, `obs:*`,
  `def:*`, `ex:*`, `lem:*`, `fig:*`, `tab:*`, `sec:*`, `ssec:*`,
  `app:*`) preserved.
- All existing numerical claims (Table 5, Table 6, Table 7,
  Table 8/scaleup; §6.5 sharpness factors; §6.6 $\bar r^{\ast\ast}$
  and $\bar r^{\ast\ast\ast}$ means; Figure 2/3/4/5 counts) unchanged.
- All CSVs (`code/experiments/logs/*.csv`, `code/results/*`) untouched.
- All `src/` Python files untouched.
- Theorem 11 statement + proof: unchanged.
- Proposition 12 statement + proof: unchanged.
- Observation 15 statement: unchanged.
- Corollary 19 statement + proof: unchanged.
- Remark 14 statement: unchanged (§7(iii) re-framed around it).
- Theorem 16 statement: "uniformly" clause clarified; proof closing
  sentence updated; numerical $O(n^{-1/2})$ rate unchanged.
- Remark 17: depot-position constant made explicit; $O(n^{-1})$ rate
  unchanged.
- Example 4 TNu allocation and Solomon-C101 numerical values
  ($\cstar=77.593$, $C(N)_{\text{online}}=80.059$, $r=1.032$)
  unchanged.
