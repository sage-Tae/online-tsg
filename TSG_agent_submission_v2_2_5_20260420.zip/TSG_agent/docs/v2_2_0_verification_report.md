# v2.2.0 verification report

Read-only verification of the v2.2.0 revision (Proposition 15 —
balanced-near-complement threshold). No file other than this report
was created or modified.

## CHECK W1 — Proposition 15 statement consistency

### W1.a Full statement and proof (main.tex §5.1, lines 353–368)

**Statement:**
> Let $n\ge 3$, $B_{n-1}=\{N\setminus\{i\}:i\in N\}$, and
> $B_{n-2}=\{N\setminus\{i,j\}:i\neq j\in N\}$. Assume
> $\F\supseteq B_{n-1}\cup B_{n-2}$, i.e.\ every size-$(n-1)$ and
> size-$(n-2)$ coalition is feasible. Let
> $\lambda=(\lambda_S)_{S\in B_{n-1}\cup B_{n-2}}$ be a vector of
> non-negative weights satisfying the balancing condition
> $\sum_{S\ni i}\lambda_S = 1$ for every $i\in N$. Define
> $r^{(\diamond)}(\lambda) := \sum_{S\in B_{n-1}\cup B_{n-2}}\lambda_S\,c(S) / \cstar(N)$.
> If the realized competitive ratio $r$ satisfies
> $r>r^{(\diamond)}(\lambda)$ for some such $\lambda$, then
> $\mathrm{Core}(N,c,\F)=\emptyset$.

**Proof (sketch inlined, lines 366–368):**
> Assume $x\in\mathrm{Core}(N,c,\F)$. The hypothesis
> $\F\supseteq B_{n-1}\cup B_{n-2}$ and $\lambda_S\ge 0$ let us sum
> Core inequalities $\sum_{i\in S}x_i\le c(S)$ with weights $\lambda_S$.
> Interchanging the finite double sum on the left and applying
> $\sum_{S\ni i}\lambda_S=1$ and the Temporal Core efficiency equality
> gives $r\,\cstar(N)=\sum_{i}x_i=\sum_S\lambda_S\sum_{i\in S}x_i\le\sum_S\lambda_S\,c(S)$,
> hence $r\le r^{(\diamond)}(\lambda)$, a contradiction. Full argument
> in Supplementary Materials §S4.

Full expanded proof appears in Supplementary §S4 lines 199–215.

### W1.b Feasibility hypothesis: strong vs weak — **PASS**

- Statement: $\F\supseteq B_{n-1}\cup B_{n-2}$ (**strong**: every size-$(n-1)$
  and size-$(n-2)$ coalition feasible).
- Proof (main.tex sketch and Supplementary expansion): uses the strong
  hypothesis to invoke the Core stability inequality
  $\sum_{i\in S}x_i\le c(S)$ for every $S\in B_{n-1}\cup B_{n-2}$.
  Supplementary §S4 line 199–202: "The feasibility hypothesis
  $\mathcal{F}\supseteq B_{n-1}\cup B_{n-2}$ guarantees that for every
  $S\in B_{n-1}\cup B_{n-2}$ the Temporal Core stability inequality
  … holds."

Statement and proof both use the strong version. No inconsistency.

### W1.c Quantifier on $\lambda$ — **PASS**

- Statement: "for some such $\lambda$".
- Proof: derives the conclusion from a *specific* $\lambda$ satisfying
  the balancing condition; the contradiction works for that $\lambda$,
  and the statement's "some $\lambda$" quantifier is therefore exactly
  what the proof supports. Neither the main-text proof nor the
  Supplementary expansion implicitly uses $\lambda^*$ (the LP minimum);
  the coverage-audit concept $r^{(\diamond)}_{\min}$ is introduced
  separately in Suppl. §S4 as the sharpest threshold in the family
  (obtained by minimizing over all admissible $\lambda$), not as the
  proof's $\lambda$. Consistent.

### W1.d Contradiction with $x\in\mathrm{Core}$ — **PASS**

The proof proceeds:
1. Assume $x\in\mathrm{Core}(N,c,\F)$.
2. Derive $r\,\cstar(N) = \sum_i x_i = \sum_S\lambda_S\sum_{i\in S}x_i
   \le \sum_S\lambda_S\,c(S) = r^{(\diamond)}(\lambda)\,\cstar(N)$.
3. Hence $r\le r^{(\diamond)}(\lambda)$, contradicting the hypothesis
   $r>r^{(\diamond)}(\lambda)$.

This is a genuine contradiction with the assumed $x\in\mathrm{Core}$,
not a tautology or the wrong direction. ✓

### W1.e Edge case $n=3$ — **PASS**

At $n=3$: $B_{n-1}=B_2$ = three size-2 coalitions, $B_{n-2}=B_1$ = three
singletons. The collection $B_{n-1}\cup B_{n-2}$ consists of 6 distinct
coalitions (sizes 1 and 2 are disjoint, so no double-indexing). Each
player $i$ appears in: 2 coalitions of $B_{n-1}$ (the size-2 coalitions
containing $i$) and 1 coalition of $B_{n-2}$ (the singleton $\{i\}$),
for a total of 3 coalitions per player. The balancing condition
$\sum_{S\ni i}\lambda_S=1$ is a well-posed linear system with multiple
feasible solutions (e.g., $\lambda_{\{i\}}=1$, $\lambda_{\{i,j\}}=0$ is
one valid balancing). The proof swaps
$\sum_S\lambda_S\sum_{i\in S}x_i = \sum_{i\in N}x_i\sum_{S\ni i}\lambda_S$
where each player appears in $\sum_{S\ni i}\lambda_S$ weighted coalitions;
no double-counting with "c({i}) singleton constraints" because the
singletons in $B_{n-2}$ *are* the singleton constraints (they appear
once in $B_{n-1}\cup B_{n-2}$, not twice). The proof is valid at $n=3$
without special-case handling. The statement's lower bound "$n\ge 3$"
is explicit.

**W1 overall verdict: PASS.**

## CHECK W2 — Coverage verdict reproducibility

### W2.a Script audit — **PASS (with a minor WARN on case-list source)**

`code/scripts/near_complement_coverage_check.py` (new in v2.2.0):

- **Imports correct generators:** lines 44 `from generators import
  generate_customers, generate_arrivals`; line 45 `from src.policies
  import make_policies`; line 46 `from src.tsp import tsp_cost, dist`.
  These match the main experiment driver. ✓
- **Case list:** lines 49–60 hard-code the 10 `(n, pattern, seed)`
  tuples. They match
  `policy_comparison_v2_full.csv[policy='nearest_neighbor' &
  empty_mechanism='near_complement']` exactly, but the script does not
  reload the CSV to derive the list — it is baked in. The spec's W2.a
  asks that the script "loads the 10 near-complement cases from the
  correct CSV"; strict reading this is a **WARN** (hardcoded list).
  Lenient reading: the list is faithful and verified in this report
  against the CSV.
- **LP formulation:** lines 169–195 in `solve_balancing_lp`. Variables
  $\lambda_S\ge 0$, equality constraints $\sum_{S\ni i}\lambda_S = 1$
  for every player, objective $\min \sum_S \lambda_S c(S)$. Solved by
  `scipy.optimize.linprog(method='highs')`. Matches the proposition's
  balancing LP exactly.
- **Restriction to $F$:** `enumerate_collection_restricted_to_F`
  (lines 146–157) iterates over $B_{n-1}$ and $B_{n-2}$ and keeps only
  $S$ satisfying $\max_{i\in S} a_i < \min_{i\in S} s_i$ (paper
  Definition 2 of feasibility, with tolerance $10^{-9}$). ✓
- **r vs r^♦ comparison:** line 218 of `check_one_case`:
  `'fires': (lp['opt_value'] is not None and r > lp['opt_value'] /
  c_star_N + 1e-9)`. Strict inequality with numerical tolerance. ✓

### W2.b Script execution — **PASS**

Re-run at 2026-04-20 on the current working tree:

```
  n  pattern    seed         r   r_diamond  fires  |Bn1∩F|  |Bn2∩F|   t(s)
 10  A           123    1.0529    1.048969    YES       10       45    0.5
 10  B_heavy     256    1.1261    1.047974    YES       10       45    0.1
 10  C           123    1.1238    1.048969    YES       10       45    0.1
 15  A            42    1.0475    1.049458    no        15      105   10.0
 15  A            99    1.0507    1.040182    YES       15      105   10.1
 15  A           123    1.0749    1.041439    YES       15      105   10.2
 15  B_heavy       7    1.1849    1.042080    YES       15      105   10.2
 15  C            42    1.0680    1.049458    YES       15      105   10.4
 15  C            99    1.1476    1.040182    YES       15      105   10.3
 15  C           123    1.1406    1.041439    YES       15      105   10.3
Coverage: 9 / 10 cases fire (r > r^♦).
```

Matches the claimed 9/10 exactly. The residual case is `(n=15, pattern=A,
seed=42)` with $r=1.0475$ and $r^{(\diamond)}=1.049458$. ✓

### W2.c No output differences — **PASS**

The re-run reproduces the claimed 9/10 and identifies the same residual
case with the same $r$ and $r^{(\diamond)}$ to 6 decimal places.

**W2 overall verdict: PASS** (W2.a hardcoded-list detail is a minor
WARN-worthy note but does not affect correctness of the coverage result;
treating as PASS since the values are verified against the CSV.)

## CHECK W3 — Table 5 and §6.4 consistency

### W3.a Table 5 numerical consistency — **PASS**

From `pdftotext main.pdf` page 18:
```
Classification                                                Core empty (obs.)  Core nonempty (obs.)  Total
Single-complement (Theorem 11 fires)                                           37                   0    37
Balanced-complement (Proposition 12 only)                                      11                   0    11
Balanced-near-complement (Proposition 15 only)                                  9                   0     9
Near-complement residual (Remark 14; no threshold fires)                        1                   0     1
Intermediate (Observation 16)                                                   9                   0     9
No mechanism predicts emptiness                                                 0                 108   108
Total                                                                          67                 108   175
```
Row sum: 37 + 11 + 9 + 1 + 9 + 0 = 67 empty + 108 nonempty = 175 total. ✓

Five-mechanism decomposition present with Proposition 15 (9 cases) and
near-complement residual (1 case).

### W3.b §6.4 references Proposition 15 and calls out residual — **PASS**

main.tex line 534 (body paragraph below Table 5):
> "Theorem 11, Proposition 12, and Proposition 15 are *sufficient*
> conditions jointly covering 57 of 67 NN empties; the remaining 10
> split into 1 near-complement residual (Remark 14, whose instance has
> $r\le r^{(\diamond)}_{\min}$ by a margin of $\approx 2\times 10^{-3}$)
> and 9 intermediate cases that are certified only by the Core LP."

main.tex line 583–588 (Five-way decomposition paragraph):
> "Near-complement residual (Remark 14, no threshold fires): **1**
> instance ($n=15$, Pattern A, seed 42; $r=1.0475$,
> $r^{(\diamond)}_{\min}=1.0495$), at $k=n$."

Explicit reference to Proposition 15, explicit call-out of the 1
residual with $r$, $r^{(\diamond)}_{\min}$, and $(n, \text{pattern},
\text{seed})$. ✓

### W3.c Stale text audit — **FAIL (two sites)**

**Stale site 1 — main.tex line 546 (§6.4 Analytic sharpness of Corollary):**
> "The analytic content of Corollary~\ref{cor:cor52} is that both
> complement-based mechanisms---single (Theorem~\ref{thm:empty-core})
> and balanced (Proposition~\ref{prop:bondareva-complement})---are
> blocked whenever the peak queue satisfies $k<n-1$, because both
> hypotheses require at least one complement $N\setminus\{i\}$ to be
> feasible, and feasibility forces $|U_t|=n-1$ at some $t$."

This text refers to "both complement-based mechanisms" (two). With
Proposition 15 added, Corollary 20 (was 19) now blocks **three**
complement-based mechanisms (Theorem 11 + Proposition 12 + Proposition
15), not two. The updated Corollary statement and proof (main.tex
lines 441–452) correctly list all three, but the §6.4 prose retains
the older "both … two-mechanism" framing. STALE.

**Stale site 2 — main.tex line 719 (§6.8 Finding 3(a)):**
> "so every complement $N\setminus\{i\}$ is infeasible and both
> complement-based mechanisms (Theorem~\ref{thm:empty-core} and
> Proposition~\ref{prop:bondareva-complement}) are structurally blocked
> by Corollary~\ref{cor:cor52}, regardless of the realized $r$."

Same issue: lists only two complement-based mechanisms; Proposition 15
is omitted. The §1 C2 item (line 76) and §7 Conclusion (line 739)
correctly list all three, but §6.4 and §6.8 Finding 3(a) retain the
pre-promotion two-mechanism language.

Neither site uses "10 cases without analytic condition" language
(the near-complement mechanism is correctly re-labeled "residual" in
Table 5 and Remark 14); W3.c's specific stale-phrase example is not
present. However, two paragraphs still claim "both" where "three"
would be correct post-promotion.

**W3 overall verdict: FAIL on W3.c** (two sites with stale
"both complement-based mechanisms" language post-Proposition-15).
W3.a and W3.b pass.

## CHECK W4 — §7(iii) open-problem refinement

### W4.a §7(iii) audit — **PASS**

main.tex line 749 (§7(iii) Near-complement residual):
> "Proposition~\ref{prop:balanced-near-complement} closes the
> near-complement mechanism analytically for 9 of 10 observed main-grid
> cases. The residual ($n=15$, A, seed 42) fails the strict inequality
> by $\approx 2\times 10^{-3}$. Whether a tighter balancing family
> ---mixing sizes $n-1,n-2,n-3$, or relaxing the efficiency equality
> to a covering inequality---closes this residual is open;
> Supplementary Materials \S S4 records the diagnostic."

- No longer treats the near-complement mechanism as fully open. ✓
- Acknowledges Proposition 15 covers 9 of 10. ✓
- Formulates a refined open problem (mix $B_{n-3}$, or relax to covering
  inequality). ✓
- Quantifies the residual gap ($\approx 2\times 10^{-3}$). ✓

## CHECK W5 — Supplementary §S4 alignment

### W5.a §S4 audit — **PASS**

Supplementary §S4 (lines 194–261):

- Section title: "Balanced-near-complement: full proof and coverage
  audit" (line 194). No "Conjecture" label for the balanced-near-
  complement result itself. ✓
- "Full proof of Proposition~15" paragraph (lines 199–215): full step-
  by-step proof with explicit Core inequality, sum-swap, balancing-
  condition application, and efficiency-equality reduction. ✓
- "Coverage on the 10 near-complement cases" and Table S4 (lines 230–253)
  report per-case $r$, $r^{(\diamond)}_{\min}$, difference, and fires
  verdict; residual (seed 42) highlighted in bold "no". ✓
- "Diagnostic for seed 42" (line 257): acknowledges the mixed $B_{n-1}
  \cup B_{n-2}$ collection is "simply not rich enough" to certify that
  instance, explicitly stating the feasibility hypothesis is met but
  the threshold inequality fails. ✓
- "Refined open problem" (line 259) labels a *new* conjecture (the
  $B_{n-1}\cup B_{n-2}\cup B_{n-3}$ enlargement) — note this is for
  the refined question about closing the residual, not a re-conjecture
  of Proposition 15 itself. ✓
- "No-false-positives note" (line 261) confirms certification is
  unilateral by construction (Proposition 15 is a *proven* sufficient
  condition, so any firing is a guaranteed empty Core). ✓

## CHECK W6 — Numbering consistency

### W6.a PDF numbering — **PASS**

Verified via `pypdf`-extracted text (compiled `main.pdf` is 30 pages):
- `Proposition 15` — 10 occurrences across pages 3, 12, 13, 15, 17, 18,
  19, 21, 27, 28.
- `Theorem 17` — 8 occurrences (pages 3, 6, 13, 15, 24, 26, 27, 28).
- `Observation 16` — 8 occurrences (pages 3, 18, 19, 20, 21, 23, 27, 28).
- `Remark 18` — 1 occurrence (page 24).
- `Proposition 19` — 2 occurrences (pages 15, 27).
- `Corollary 20` — 12 occurrences.
- `Theorem 16` — **0 occurrences** (old asymptotic now 17).
- `Observation 15` — **0 occurrences** (old intermediate now 16).
- `Corollary 19` — **0 occurrences** (old structural obstruction now 20).
- `Theorem 11`, `Proposition 12`, `Remark 14` — all retained at their
  pre-shift numbers, as expected (they precede the insertion point).

All shifts consistent with a single insertion at position 15.

### W6.b Cross-reference resolution — **PASS**

main.pdf compiled with 0 undefined references and 0 undefined citations
(final pdflatex pass clean). All `\ref{thm:...}`, `\ref{prop:...}`,
`\ref{cor:...}`, `\ref{obs:...}`, `\ref{rem:...}` resolve correctly.
Body text numbering (sampled at lines 76, 88, 515, 525, 534, 546, 749)
uses `\ref{}` throughout; no stale hard-coded numbers found via grep.

### W6.c README / REPRODUCIBILITY / docs — **PASS**

- `README.md` line 42 (Key results, current-state): uses new
  "Proposition 15 balanced-near-complement fires". ✓
- `README.md` line 25 (v2.2.0 history entry): describes the numbering
  shift explicitly. EXPECTED.
- `README.md` line 14 (v2.1.2 history): references old "Observation 15"
  — HISTORICAL, describing v2.1.2 state. EXPECTED.
- `README.md` line 23 (v2.1.11 history): references old "Theorem 16",
  "Remark 17", "Thm 18 downgraded" — HISTORICAL. EXPECTED.
- `README.md` line 96 (v2.1.12 tag): "Theorem 11, Proposition 12,
  Observation 15, Corollary 19 statements / CSVs / `src/` unchanged
  bit-for-bit" — HISTORICAL description of v2.1.12's invariants.
  EXPECTED.
- `README.md` line 97 (v2.2.0 tag): describes shift. CURRENT. ✓
- `REPRODUCIBILITY.md` lines 239, 248, 250: all v2.1.x version-history
  entries; old numbers only appear in historical descriptions.
  EXPECTED.

No stale current-state numbering references found.

**W6 overall verdict: PASS.**

## CHECK W7 — "Near-miss" honesty

### W7.a and W7.b Phrase audit — **WARN**

Strict interpretation of the spec's forbidden-list ("essentially fires",
"within numerical precision", "nearly satisfies", "or similar"):

- `paper/main.tex` — 0 occurrences of "essentially fires", "within
  numerical precision", "nearly satisfies", "near-miss". Descriptions
  of the residual use "falls just below" (line 59 abstract),
  "threshold-bound by ≈ 2×10^{-3}" (line 78), "fails the strict
  inequality by ≈ 2×10^{-3}" (line 749), "has $r\le r^{(\diamond)}_{\min}$
  by a margin of" (line 534), "$r=1.0475$, $r^{(\diamond)}_{\min}=1.0495$,
  at $k=n$" (line 585). All honest acknowledgments of failure with
  quantitative margin — no claim of effective firing.
- `paper/supplementary.tex` — 0 occurrences of the forbidden phrases.
  §S4 line 255 uses "by a margin of ≈ 2×10^{-3}"; line 257 uses
  "the mixed $B_{n-1}\cup B_{n-2}$ collection is simply not rich enough
  to certify this particular instance's emptiness". Honest.
- `docs/v2_1_12_to_v2_2_0_response.md` — **1 occurrence** of "near-miss"
  at line 41: "$r = 1.0475 < r^{(\diamond)}_{\min} = 1.049458$, a
  near-miss by $\approx 2\times 10^{-3}$." The phrase "near-miss" is
  close in spirit to the forbidden "nearly satisfies"; strict reading
  would flag this as FAIL for the response doc. Lenient reading:
  "near-miss" honestly describes the margin of failure (the case
  failed, just by a small amount), does not claim the case is
  certified, and appears near the sentence "remains certified only by
  the first-stage Core LP" which is clear about the mechanism.
- `docs/phase2_option1_log.md` — **1 occurrence** of "near-miss" at
  line 52 (same context, same reading).

Neither `paper/main.tex` nor `paper/supplementary.tex` contains any of
the forbidden phrases or "near-miss". The response doc and working log
each contain one "near-miss" in a context that honestly acknowledges
failure.

**W7 overall verdict: WARN** — paper and supplementary are clean; the
phrase "near-miss" appears in two non-paper artifacts (response doc
line 41 and working log line 52) where a stricter reading of the spec's
"or similar" would treat it as forbidden, though the surrounding text
makes clear the residual case failed the sufficient condition.

## CHECK W8 — Log file and response doc

### W8.a `docs/phase2_option1_log.md` — **PASS**

- Timestamped stage transitions at 22:25, 22:35, 22:40, 23:05, 23:10 KST. ✓
- Coverage verdict (9/10) with full case-level data (all 10 rows from
  the script output quoted verbatim). ✓
- Proof-sketch steps re-verified one by one with explicit
  "✓" markers; no step marked "clearly" or "easy to see". The agent
  did note a page-budget tension at first rebuild (32 pages) and
  documented the compressions applied. ✓
- Final path chosen: STAGE 2+3 success (line 113). ✓

### W8.b `docs/v2_1_12_to_v2_2_0_response.md` — **PASS**

- Stage verdicts table (S1 9/10, S2 promoted, S3 passed, version
  v2.2.0) present. ✓
- Proposition statement and proof structure summarized. ✓
- What-changed-in-manuscript detailed listing per file
  (main.tex / supplementary.tex / code / docs). ✓
- Self-audit record enumerates 7 proof-verification steps. ✓
- Invariants preserved: CSV, `src/`, figures, prior theorem statements
  all flagged as unchanged. ✓
- Final gates PASS recorded. ✓

**W8 overall verdict: PASS.**
