# v2.2.0 → v2.2.1 response

Minimal-scope documentation-consistency patch against the v2.2.0
verification report `docs/v2_2_0_verification_report.md`. Only prose
paragraphs inside three main.tex sites and two non-paper artifacts are
touched. No changes to Proposition 15, its proof, Supplementary §S4,
CSVs, code, figures, or any numerical result.

## Summary

| Patch | Item | Status | Addresses |
|---|---|---|---|
| P1 | Stale "both complement-based mechanisms" prose in main.tex | **Done** | W3.c FAIL |
| P2 | "near-miss" wording in response doc + log | **Done** | W7 WARN |
| — | Version bump v2.2.0 → v2.2.1 | **Done** | — |

## P1 — "both" → "all three" complement-based mechanisms

After Proposition 15 was added in v2.2.0, Corollary 20 (structural
obstruction at $k<n-1$) now blocks three complement-based mechanisms,
not two. Corollary 20's own statement and proof (main.tex lines 439–446)
already list all three — Theorem 11, Proposition 12, Proposition 15 —
but three downstream prose paragraphs in §6.4, §6.8, and §7 still used
the pre-v2.2.0 "both (Theorem 11 and Proposition 12)" framing. The
logical basis is unchanged: each of the three hypotheses requires at
least one complement $N\setminus\{i\}$ to be feasible (Thm 11
explicitly; Prop 12 and Prop 15 even more so, since both require
$B_{n-1}\subseteq\mathcal{F}$), and $k<n-1$ forces every $N\setminus\{i\}$
infeasible.

### P1.a main.tex line 546 (§6.4 "Analytic sharpness of Corollary 20")

Before:
> "The analytic content of Corollary~\ref{cor:cor52} is that both
> complement-based mechanisms---single (Theorem~\ref{thm:empty-core})
> and balanced (Proposition~\ref{prop:bondareva-complement})---are
> blocked whenever the peak queue satisfies $k<n-1$, because both
> hypotheses require at least one complement $N\setminus\{i\}$ to be
> feasible, and feasibility forces $|U_t|=n-1$ at some $t$. Empirically
> this holds without exception in the 175-instance grid: no NN (or CI,
> BR) instance with $k<n-1$ satisfies $r>r^{\ast\ast}$ or
> $r>r^{\ast\ast\ast}$ (false-positive count is zero for both thresholds
> across all 525 policy-instance pairs)."

After:
> "The analytic content of Corollary~\ref{cor:cor52} is that all three
> complement-based mechanisms---single (Theorem~\ref{thm:empty-core}),
> balanced (Proposition~\ref{prop:bondareva-complement}), and
> balanced-near-complement
> (Proposition~\ref{prop:balanced-near-complement})---are blocked
> whenever the peak queue satisfies $k<n-1$, because each hypothesis
> requires at least one complement $N\setminus\{i\}$ to be feasible,
> and feasibility forces $|U_t|=n-1$ at some $t$. Empirically this
> holds without exception in the 175-instance grid: no NN (or CI, BR)
> instance with $k<n-1$ satisfies $r>r^{\ast\ast}$, $r>r^{\ast\ast\ast}$,
> or $r>r^{(\diamond)}_{\min}$ (false-positive count is zero for all
> three thresholds across all 525 policy-instance pairs)."

### P1.b main.tex line 719 (§6.8 Finding 3(a))

Before:
> "so every complement $N\setminus\{i\}$ is infeasible and both
> complement-based mechanisms (Theorem~\ref{thm:empty-core} and
> Proposition~\ref{prop:bondareva-complement}) are structurally blocked
> by Corollary~\ref{cor:cor52}, regardless of the realized $r$."

After:
> "so every complement $N\setminus\{i\}$ is infeasible and all three
> complement-based mechanisms (Theorem~\ref{thm:empty-core},
> Proposition~\ref{prop:bondareva-complement}, and
> Proposition~\ref{prop:balanced-near-complement}) are structurally
> blocked by Corollary~\ref{cor:cor52}, regardless of the realized $r$."

### P1.c Additional site found during the grep sweep

main.tex line 741 (§7 Platform-design implication) contained the same
pre-v2.2.0 "both" phrasing and was updated to "all three":

Before:
> "structurally rules out both complement-coalition empty-Core mechanisms"

After:
> "structurally rules out all three complement-coalition empty-Core
> mechanisms"

### P1.d Final grep sweep

```
grep -nE "both complement|two complement|two-mechanism|blocks both|only two" \
     paper/main.tex paper/supplementary.tex
```
returns **0 hits** after the three edits.

## P2 — Remove "near-miss" from non-paper artifacts

The paper itself (main.tex and supplementary.tex) was already clean of
the spec's forbidden phrasings ("essentially fires", "nearly satisfies",
"within numerical precision", or similar). The word "near-miss"
appeared twice, both in non-paper artifacts.

### P2.a docs/v2_1_12_to_v2_2_0_response.md (line 41 region)

Before:
> "The single residual case `(n=15, A, seed=42)` has
> `$r = 1.0475 < r^{(\diamond)}_{\min} = 1.049458$`, a near-miss by
> `$\approx 2\times 10^{-3}$`."

After:
> "The single residual case `(n=15, A, seed=42)` has
> `$r = 1.0475 < r^{(\diamond)}_{\min} = 1.049458$`, failing the strict
> inequality by approximately `$2\times 10^{-3}$`."

### P2.b docs/phase2_option1_log.md (line 52 region)

Before:
> "…is `(n=15, pattern=A, seed=42)` with `r=1.0475` and
> `r^♦=1.049458` (near-miss by ~0.002). In every case, both
> `|B_{n-1} ∩ F| = n` and…"

After:
> "…is `(n=15, pattern=A, seed=42)` with `r=1.0475` and
> `r^♦=1.049458` (fails the strict inequality by approximately 0.002).
> In every case, both `|B_{n-1} ∩ F| = n` and…"

### P2.c Confirmation grep

```
grep -nE "near-miss|nearly satisfies|essentially fires|within numerical precision" \
     docs/v2_1_12_to_v2_2_0_response.md docs/phase2_option1_log.md
```
returns **0 hits** after the two edits.

## Version bump

- `README.md`: v2.2.0 → v2.2.1 current-version label; "Key results"
  header label; v2.2.1 version-history entry; v2.2.1 Reproducibility-
  tags entry (v2.2.0 demoted to intermediate).
- `REPRODUCIBILITY.md`: title, Paper Info block, Data Files header,
  "not the basis for v2.2.0" body line, `verify_zip_rebuild.sh` gate
  label, Version History entry (v2.2.0 demoted, v2.2.1 added).
- `scripts/verify_doc_consistency.sh`: `CURRENT_VERSION=v2.2.1`;
  stale-version regex broadened to also flag `v2.2.0`.

## Invariants preserved

- Proposition 15 (`\begin{proposition}[Balanced-near-complement
  threshold]\label{prop:balanced-near-complement}…\end{proposition}`)
  at main.tex lines 353–364 is byte-identical to v2.2.0.
- Inline proof sketch at main.tex lines 366–368 is byte-identical.
- Relation paragraph at main.tex line 370 is byte-identical.
- Supplementary §S4 (lines 194–261) is byte-identical.
- Coverage script `code/scripts/near_complement_coverage_check.py` and
  its output `code/results/near_complement_coverage_check.csv` are
  byte-identical.
- Table 5 row counts (37 + 11 + 9 + 1 + 9 = 67) unchanged.
- All numerical results (4.351 / 1.223 / 1.096; sharpness 3.56 / 3.97;
  Example 4 allocation) unchanged.
- CSVs under `code/experiments/logs/` and `code/results/` unchanged.
- Figures under `code/figures/` unchanged.
- `code/src/` unchanged.

## Final gates (expected)

- `scripts/verify_doc_consistency.sh` — expected PASS with v2.2.1,
  main 30, supp 8, seed123 = 2.
- `scripts/verify_zip_rebuild.sh <zip>` — expected PASS; main.pdf ≤ 30
  pages, supp 8, highlights 1.

## Residual items from `v2_2_0_verification_report.md`

- W3.c FAIL (stale "two-mechanism" prose) — **addressed by P1**.
- W7 WARN ("near-miss" phrasing) — **addressed by P2**.

All other verification items were PASS and are unaffected.
